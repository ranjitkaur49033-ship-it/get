import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini SDK with User-Agent and key
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-Memory Market Data Store
interface Candlestick {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface AssetData {
  symbol: string;
  name: string;
  category: "Forex" | "Crypto" | "Commodities" | "Stocks";
  basePrice: number;
  currentPrice: number;
  changePercent: number;
  history: Candlestick[];
  high24h: number;
  low24h: number;
  volume24h: number;
}

const ASSET_SPECS = [
  { symbol: "EUR/USD", name: "Euro / US Dollar", category: "Forex" as const, basePrice: 1.0852, volatility: 0.0006 },
  { symbol: "GBP/USD", name: "British Pound / US Dollar", category: "Forex" as const, basePrice: 1.2724, volatility: 0.0008 },
  { symbol: "USD/JPY", name: "US Dollar / Japanese Yen", category: "Forex" as const, basePrice: 156.42, volatility: 0.08 },
  { symbol: "BTC/USD", name: "Bitcoin / US Dollar", category: "Crypto" as const, basePrice: 67450.00, volatility: 180.00 },
  { symbol: "ETH/USD", name: "Ethereum / US Dollar", category: "Crypto" as const, basePrice: 3510.50, volatility: 12.00 },
  { symbol: "XAU/USD", name: "Gold / US Dollar", category: "Commodities" as const, basePrice: 2332.10, volatility: 1.80 },
  { symbol: "AAPL", name: "Apple Inc. Stock", category: "Stocks" as const, basePrice: 192.45, volatility: 0.35 }
];

const assets: Map<string, AssetData> = new Map();

// Helper to generate initial 50 historical candles (1M intervals to simulate recent lookback)
function generateHistoricalCandles(basePrice: number, volatility: number, count = 50): Candlestick[] {
  const history: Candlestick[] = [];
  let currentClose = basePrice - (count * (Math.random() - 0.5) * volatility);
  const now = Date.now();
  
  for (let i = count; i > 0; i--) {
    const timeStr = new Date(now - i * 60000).toLocaleTimeString("en-US", { hour12: false });
    const change = (Math.random() - 0.5) * volatility;
    const open = currentClose;
    const close = open + change;
    const maxVal = Math.max(open, close);
    const minVal = Math.min(open, close);
    const high = maxVal + Math.random() * (volatility * 0.4);
    const low = minVal - Math.random() * (volatility * 0.4);
    const volume = Math.floor(100 + Math.random() * 900);
    
    history.push({
      time: timeStr.substring(0, 5),
      open,
      high,
      low,
      close,
      volume
    });
    currentClose = close;
  }
  return history;
}

// Initialize all assets
ASSET_SPECS.forEach(spec => {
  const history = generateHistoricalCandles(spec.basePrice, spec.volatility);
  const lastPrice = history[history.length - 1].close;
  const initHigh = Math.max(...history.map(h => h.high));
  const initLow = Math.min(...history.map(h => h.low));
  const totalVolume = history.reduce((sum, h) => sum + h.volume, 0);

  assets.set(spec.symbol, {
    symbol: spec.symbol,
    name: spec.name,
    category: spec.category,
    basePrice: spec.basePrice,
    currentPrice: lastPrice,
    changePercent: ((lastPrice - spec.basePrice) / spec.basePrice) * 100,
    history,
    high24h: initHigh,
    low24h: initLow,
    volume24h: totalVolume
  });
});

// Periodic market update ticks mimicking order book movements (every 1.5 seconds)
setInterval(() => {
  ASSET_SPECS.forEach(spec => {
    const asset = assets.get(spec.symbol);
    if (!asset) return;

    const drift = (Math.random() - 0.5) * spec.volatility * 0.3;
    const previousPrice = asset.currentPrice;
    const newPrice = previousPrice + drift;
    
    asset.currentPrice = newPrice;
    asset.changePercent = ((newPrice - asset.basePrice) / asset.basePrice) * 100;
    
    // Update the last candle or create a new one every minute
    const lastCandle = asset.history[asset.history.length - 1];
    const nowTime = new Date().toLocaleTimeString("en-US", { hour12: false }).substring(0, 5);
    
    if (lastCandle && lastCandle.time === nowTime) {
      lastCandle.close = newPrice;
      if (newPrice > lastCandle.high) lastCandle.high = newPrice;
      if (newPrice < lastCandle.low) lastCandle.low = newPrice;
      lastCandle.volume += Math.floor(Math.random() * 10);
    } else {
      // New candle! Roll the history array (keep max 60)
      if (asset.history.length >= 60) {
        asset.history.shift();
      }
      asset.history.push({
        time: nowTime,
        open: previousPrice,
        high: Math.max(previousPrice, newPrice),
        low: Math.min(previousPrice, newPrice),
        close: newPrice,
        volume: Math.floor(10 + Math.random() * 90)
      });
    }

    // Update 24h ranges
    if (newPrice > asset.high24h) asset.high24h = newPrice;
    if (newPrice < asset.low24h) asset.low24h = newPrice;
    asset.volume24h += Math.floor(Math.random() * 5);
  });
}, 1500);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Parse JSON bodies
  app.use(express.json());

  // API 1: Get Current Market Prices and Candlestick Histories
  app.get("/api/market-data", (req, res) => {
    res.json(Array.from(assets.values()));
  });

  // API 2: Analyze Asset Sentiment (Gemini API with robust fallbacks)
  app.post("/api/analyze-sentiment", async (req, res) => {
    const { symbol } = req.body;
    if (!symbol) {
      return res.status(400).json({ error: "Symbol is required" });
    }

    const asset = assets.get(symbol);
    const assetName = asset ? asset.name : symbol;
    const currentPriceStr = asset ? asset.currentPrice.toFixed(symbol.includes("JPY") ? 2 : 4) : "1.0850";

    // Fallback Mock Generation if AI is not configured/failed
    const generateFallbackSentiment = () => {
      const isUp = asset ? asset.changePercent >= 0 : Math.random() > 0.4;
      const sentiment = isUp ? (Math.random() > 0.5 ? "Strong Bullish" : "Bullish") : (Math.random() > 0.5 ? "Strong Bearish" : "Bearish");
      const score = isUp ? parseFloat((0.2 + Math.random() * 0.7).toFixed(2)) : parseFloat((-0.2 - Math.random() * 0.7).toFixed(2));
      const rsiVal = isUp ? (60 + Math.random() * 15).toFixed(1) : (30 + Math.random() * 18).toFixed(1);
      const action = isUp ? "BUY" : "SELL";
      
      return {
        symbol,
        sentiment,
        score,
        summary: `Market sentiment for **${assetName}** is currently **${sentiment}**. Spot prices are consolidating around *${currentPriceStr}* after minor resistance fluctuations. Technical charts indicate immediate moving average indicators align with key oscillators suggesting potential momentum breakouts. Keep a close watch on momentum bounds and immediate trendline support zones.`,
        news: [
          {
            title: isUp ? `${symbol} surges past key MA boundary lines on high volume` : `${symbol} slides as institutional liquidations triggers sell support`,
            source: "ProfitX Global",
            timestamp: "5 mins ago",
            impact: isUp ? "High Positive" : "High Negative"
          },
          {
            title: `Global macro indicators adjust yields, impacting secondary ${symbol.split('/')[0]} channels`,
            source: "Market Feed",
            timestamp: "32 mins ago",
            impact: "Neutral"
          }
        ],
        technicalIndicators: {
          rsi: `${rsiVal} (${parseFloat(rsiVal) > 65 ? "Neutral-Overbought" : parseFloat(rsiVal) < 35 ? "Neutral-Oversold" : "Balanced Momentum"})`,
          macd: isUp ? "Bullish MACD Line Crossing Signal Crossover" : "Bearish Signal Divergence",
          movingAverages: isUp ? "10-day & 50-day EMA: Golden Cross (BUY)" : "10-day & 50-day EMA: Death Cross (SELL)"
        },
        tradingRecommendation: {
          action,
          entry: (asset ? asset.currentPrice * (isUp ? 0.999 : 1.001) : 1.0850).toFixed(symbol.includes("JPY") || symbol.includes("BTC") ? 2 : 5),
          takeProfit: (asset ? asset.currentPrice * (isUp ? 1.015 : 0.985) : 1.1020).toFixed(symbol.includes("JPY") || symbol.includes("BTC") ? 2 : 5),
          stopLoss: (asset ? asset.currentPrice * (isUp ? 0.992 : 1.008) : 1.0770).toFixed(symbol.includes("JPY") || symbol.includes("BTC") ? 2 : 5),
          duration: "15m - 1H"
        }
      };
    };

    if (!ai) {
      // Return the fallback generator response
      return res.json(generateFallbackSentiment());
    }

    try {
      const prompt = `You are an elite, highly technical quantitative trading researcher and market signal developer.
Analyze the trading instrument "${symbol}" ("${assetName}") whose current price is ${currentPriceStr}.
Provide a thorough sentiment assessment, evaluating MACD crossovers, RSI oscillators, SMA/EMA supports, and macro fundamental news.
Return your response STRICTLY in JSON format following this TypeScript interface structure:
{
  "symbol": string,
  "sentiment": "Strong Bullish" | "Bullish" | "Neutral" | "Bearish" | "Strong Bearish",
  "score": number, // floating number between -1.0 (extremely bearish) and 1.0 (extremely bullish)
  "summary": string, // Detailed analytical report in rich markdown format, naming resistance/support thresholds and recent events. Make it look like high-quality research.
  "news": Array<{ title: string, source: string, timestamp: string, impact: "High Positive" | "Positive" | "Neutral" | "Negative" | "High Negative" }>, // 2 distinct realistic simulated breaking headlines influencing this pair
  "technicalIndicators": { rsi: string, macd: string, movingAverages: string },
  "tradingRecommendation": { action: "BUY" | "SELL" | "HOLD", entry: string, takeProfit: string, stopLoss: string, duration: string }
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              symbol: { type: Type.STRING },
              sentiment: { type: Type.STRING },
              score: { type: Type.NUMBER },
              summary: { type: Type.STRING },
              news: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    source: { type: Type.STRING },
                    timestamp: { type: Type.STRING },
                    impact: { type: Type.STRING }
                  },
                  required: ["title", "source", "timestamp", "impact"]
                }
              },
              technicalIndicators: {
                type: Type.OBJECT,
                properties: {
                  rsi: { type: Type.STRING },
                  macd: { type: Type.STRING },
                  movingAverages: { type: Type.STRING }
                },
                required: ["rsi", "macd", "movingAverages"]
              },
              tradingRecommendation: {
                type: Type.OBJECT,
                properties: {
                  action: { type: Type.STRING },
                  entry: { type: Type.STRING },
                  takeProfit: { type: Type.STRING },
                  stopLoss: { type: Type.STRING },
                  duration: { type: Type.STRING }
                },
                required: ["action", "entry", "takeProfit", "stopLoss", "duration"]
              }
            },
            required: ["symbol", "sentiment", "score", "summary", "news", "technicalIndicators", "tradingRecommendation"]
          }
        }
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        return res.json(parsed);
      } else {
        throw new Error("Empty Gemini response");
      }
    } catch (err: any) {
      console.error("Gemini sentiment analysis failed: ", err.message);
      // Fallback on failure
      return res.json(generateFallbackSentiment());
    }
  });

  // API 3: Generate Highly Accurate Trading Signals (CALL/PUT) mimicking the ProfitX design exactly
  app.post("/api/generate-signal", async (req, res) => {
    const { symbol, productType, tradingPlatform } = req.body;
    if (!symbol) {
      return res.status(400).json({ error: "Symbol is required" });
    }

    const platform = tradingPlatform || "QUOTEX";
    const mode = productType || "LIVE";

    const generateFallbackSignal = () => {
      const isCall = Math.random() > 0.45;
      const confidence = Math.floor(78 + Math.random() * 20);
      const currentTimeStr = new Date().toLocaleTimeString("en-US", { hour12: false });
      const expMinutes = [1, 2, 5, 15][Math.floor(Math.random() * 4)];
      
      const details = isCall 
        ? [
            "Order book exhibits persistent institutional cluster bids at local Support-1 level.",
            "Short-term Stochastic oscillator crossed up from oversold boundary.",
            "VAP volume accumulation profile points to a minor squeeze trigger on high volume."
          ]
        : [
            "Heavy distribution pressure noted near key horizontal pivot resistance level.",
            "Overextended momentum on M5 timeframe triggering early mean-reverting sells.",
            "Average True Range (ATR) indicates high likelihood of downside squeeze volatility."
          ];
          
      return {
        symbol,
        direction: isCall ? "CALL" : "PUT",
        confidence,
        strength: confidence >= 90 ? "STRONG" : (confidence >= 82 ? "STRONG" : "MEDIUM"),
        expiry: `${expMinutes} MIN`,
        timestamp: currentTimeStr,
        accuracyRating: `${(85 + Math.random() * 11).toFixed(1)}%`,
        reasons: details
      };
    };

    if (!ai) {
      return res.json(generateFallbackSignal());
    }

    try {
      const prompt = `You are a high-fidelity quantitative analysis engine generating ultra short-term binary option trade insights.
Produce a prediction/signal for asset "${symbol}" on trading platform "${platform}" operating under "${mode}" terms.
Return your prediction STRICTLY in JSON matching this schema:
{
  "symbol": string, // e.g. "EUR/USD"
  "direction": "CALL" | "PUT",
  "confidence": number, // integer percentage confidence value from 60 to 98
  "strength": "STRONG" | "MEDIUM" | "WEAK",
  "expiry": "1 MIN" | "2 MIN" | "5 MIN" | "15 MIN",
  "timestamp": string, // Current simulated server event timestamp e.g. "09:41:30"
  "accuracyRating": string, // calculated system backtest accuracy percentage like "92.4%"
  "reasons": string[] // Exactly 3 concise mathematical / indicators reasons (strings) justifying this trading bias
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              symbol: { type: Type.STRING },
              direction: { type: Type.STRING },
              confidence: { type: Type.INTEGER },
              strength: { type: Type.STRING },
              expiry: { type: Type.STRING },
              timestamp: { type: Type.STRING },
              accuracyRating: { type: Type.STRING },
              reasons: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["symbol", "direction", "confidence", "strength", "expiry", "timestamp", "accuracyRating", "reasons"]
          }
        }
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        return res.json(parsed);
      } else {
        throw new Error("Empty signal text");
      }
    } catch (err: any) {
      console.error("Gemini signal generation failed: ", err.message);
      return res.json(generateFallbackSignal());
    }
  });

  // API 4: System Mock Fluctuations Feed
  const systemAlerts = [
    { id: 1, type: "spurt", symbol: "BTC/USD", message: "BTC/USD surged +1.8% in 3 mins breaching local resistance.", severity: "high", time: "Just now" },
    { id: 2, type: "macro", symbol: "EUR/USD", message: "Macro: Fed Core Inflation data scheduled in 15 minutes. Prepare for heavy volatility spreads.", severity: "medium", time: "10m ago" },
    { id: 3, type: "drop", symbol: "AAPL", message: "AAPL dropped below $192 support level representing high volume institutional sellbacks.", severity: "low", time: "24m ago" },
    { id: 4, type: "signal", symbol: "XAU/USD", message: "Gold index technical indicators align: Perfect MA buy-divergence noted.", severity: "medium", time: "1h ago" }
  ];

  app.get("/api/system-alerts", (req, res) => {
    res.json(systemAlerts);
  });

  // Vite development middleware vs. static build folder
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

startServer();
