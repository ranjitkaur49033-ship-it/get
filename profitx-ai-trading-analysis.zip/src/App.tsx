import { useState, useEffect, useRef } from "react";
import { 
  TrendingUp, 
  Activity, 
  Sparkles, 
  Bell, 
  DollarSign, 
  Flame, 
  ChevronRight, 
  MessageSquare,
  Shield, 
  Volume2, 
  Globe, 
  Award,
  BookOpen,
  HelpCircle,
  CircleAlert,
  SlidersHorizontal,
  X
} from "lucide-react";
import ProfitXHeader from "./components/ProfitXHeader";
import MarketSelector from "./components/MarketSelector";
import InteractiveChart from "./components/InteractiveChart";
import AlertManager from "./components/AlertManager";
import SignalAnalysis from "./components/SignalAnalysis";
import SentimentIntelligence from "./components/SentimentIntelligence";
import LiveAnalysisPanel from "./components/LiveAnalysisPanel";
import { Asset, AISignal, SentimentData, PriceAlert, SystemFeedAlert } from "./types";

interface LiveToast {
  id: string;
  type: "success" | "error" | "info" | "warning";
  title: string;
  text: string;
}

export default function App() {
  // Demo Wallet balance starting at $10,456.78 matching user reference exactly
  const [balance, setBalance] = useState<number>(() => {
    const saved = localStorage.getItem("profitx_balance");
    return saved ? parseFloat(saved) : 10456.78;
  });

  // UI Active selectors
  const [selectedSymbol, setSelectedSymbol] = useState("EUR/USD");
  const [activePlatform, setActivePlatform] = useState("QUOTEX");
  const [activeProduct, setActiveProduct] = useState<"LIVE" | "OTC">("OTC");
  const [activeMobileTab, setActiveMobileTab] = useState<"HOME" | "SIGNALS" | "SENTIMENT" | "ALERTS">("HOME");

  // Feeds/State
  const [assets, setAssets] = useState<Asset[]>([]);
  const [currentSignal, setCurrentSignal] = useState<AISignal | null>(null);
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  
  // Custom alerts list
  const [userAlerts, setUserAlerts] = useState<PriceAlert[]>(() => {
    const saved = localStorage.getItem("profitx_user_alerts");
    return saved ? JSON.parse(saved) : [];
  });

  // Automated logs stream
  const [systemFeed, setSystemFeed] = useState<SystemFeedAlert[]>([]);
  const [unreadAlertsCount, setUnreadAlertsCount] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Loadings
  const [isGeneratingSignal, setIsGeneratingSignal] = useState(false);
  const [isRefreshingSentiment, setIsRefreshingSentiment] = useState(false);

  // Dynamic Toast Alerts list
  const [toasts, setToasts] = useState<LiveToast[]>([]);

  // Local storage setters
  useEffect(() => {
    localStorage.setItem("profitx_balance", balance.toString());
  }, [balance]);

  useEffect(() => {
    localStorage.setItem("profitx_user_alerts", JSON.stringify(userAlerts));
  }, [userAlerts]);

  // Toast adder
  const addToast = (type: "success" | "error" | "info" | "warning", title: string, text: string) => {
    const id = Math.random().toString();
    setToasts((prev) => [...prev, { id, type, title, text }]);
    
    // Play sound if allowed
    if (soundEnabled) {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        if (type === "success") {
          // Double ding (happy major chord)
          oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
          oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
          gainNode.gain.setValueAtTime(0.08, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.25);
          oscillator.start();
          oscillator.stop(audioContext.currentTime + 0.3);
        } else if (type === "error") {
          // Low flat bzz
          oscillator.type = "sawtooth";
          oscillator.frequency.setValueAtTime(120, audioContext.currentTime);
          gainNode.gain.setValueAtTime(0.06, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          oscillator.start();
          oscillator.stop(audioContext.currentTime + 0.35);
        } else {
          // Soft synth clean chirp
          oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4
          gainNode.gain.setValueAtTime(0.05, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
          oscillator.start();
          oscillator.stop(audioContext.currentTime + 0.2);
        }
      } catch (err) {
        // Safe browser silence fallback
      }
    }

    // Auto removal
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  // Initial mock fetch + live loop intervals
  useEffect(() => {
    const fetchMarketAndAlerts = async (isInitial = false) => {
      try {
        const res = await fetch("/api/market-data");
        const data: Asset[] = await res.json();
        setAssets(data);

        // Check configured user alerts for threshold triggers! Price comparison
        setUserAlerts((prevAlerts) => {
          let updated = false;
          const next = prevAlerts.map((alert) => {
            if (alert.triggered) return alert;

            const current = data.find((a) => a.symbol === alert.symbol);
            if (!current) return alert;

            let isTriggered = false;
            if (alert.condition === "ABOVE" && current.currentPrice >= alert.targetPrice) {
              isTriggered = true;
            } else if (alert.condition === "BELOW" && current.currentPrice <= alert.targetPrice) {
              isTriggered = true;
            }

            if (isTriggered) {
              updated = true;
              addToast(
                "warning",
                "PRICE TARGET BREACHED",
                `${alert.symbol} trading has crossed target standard ${alert.targetPrice} (Condition: ${alert.condition}).`
              );
              
              // Prep background logger message
              const newLog: SystemFeedAlert = {
                id: Math.random(),
                type: "alert",
                symbol: alert.symbol,
                message: `ALERT TRIGGER: Standard price crossed local custom target threshold ${alert.targetPrice} (${alert.condition}).`,
                severity: "high",
                time: "Just now"
              };
              setSystemFeed((prevFeed) => [newLog, ...prevFeed]);
              setUnreadAlertsCount((c) => c + 1);

              return { ...alert, triggered: true };
            }
            return alert;
          });
          return updated ? next : prevAlerts;
        });

      } catch (err) {
        console.error("Failed loading market states: ", err);
      }
    };

    const fetchSystemLogs = async () => {
      try {
        const res = await fetch("/api/system-alerts");
        const data = await res.json();
        setSystemFeed(data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchMarketAndAlerts(true);
    fetchSystemLogs();

    // Setup pollers
    const marketInterval = setInterval(() => fetchMarketAndAlerts(), 1500);
    return () => {
      clearInterval(marketInterval);
    };
  }, [userAlerts, soundEnabled]);

  // Autoload signals and sentiment upon selecting different pairs to make dashboard immersive
  useEffect(() => {
    if (assets.length > 0) {
      triggerSignalGeneration();
      triggerSentimentRefresh();
    }
  }, [selectedSymbol]);

  // API Signal Generator Trigger
  const triggerSignalGeneration = async () => {
    setIsGeneratingSignal(true);
    try {
      const res = await fetch("/api/generate-signal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: selectedSymbol,
          productType: activeProduct,
          tradingPlatform: activePlatform,
        }),
      });
      const data: AISignal = await res.json();
      setCurrentSignal(data);
      // Fire small alert tone
      addToast(
        "info",
        "NEW ALGORITHMIC SIGNALREADY",
        `${selectedSymbol}: Predicted ${data.direction} with ${data.confidence}% confidence rating.`
      );
    } catch (err) {
      addToast("error", "AI PIPELINE OFFLINE", "Failed loading trading signals.");
    } finally {
      setIsGeneratingSignal(false);
    }
  };

  // API Sentiment Refresh Trigger
  const triggerSentimentRefresh = async () => {
    setIsRefreshingSentiment(true);
    try {
      const res = await fetch("/api/analyze-sentiment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: selectedSymbol }),
      });
      const data: SentimentData = await res.json();
      setSentiment(data);
    } catch (err) {
      addToast("error", "AI INTELLIGENCE FAILURE", "Failed compiling sentiment analyzer.");
    } finally {
      setIsRefreshingSentiment(false);
    }
  };

  const handleWalletDeposit = (amount: number) => {
    setBalance((prev) => prev + amount);
    addToast("success", "WALLET FUNDED SUCCESSFULLY", `Credited $${amount.toFixed(2)} mock tokens to account.`);
  };

  // Executes actual simulations inside active countdown bets page
  const handleExecuteMockTradeChange = (deltaVolume: number) => {
    setBalance((prev) => prev + deltaVolume);
  };

  // Alert Manager register creator
  const handleCreateCustomAlert = (symbol: string, targetPrice: number, condition: "ABOVE" | "BELOW") => {
    const newAlert: PriceAlert = {
      id: Math.random().toString(),
      symbol,
      targetPrice,
      condition,
      triggered: false,
      createdAt: new Date().toLocaleTimeString(),
    };
    setUserAlerts((prev) => [newAlert, ...prev]);
    addToast(
      "success",
      "THRESHOLD ALARM ACTIVATED",
      `Registered alert tracking on ${symbol} ${condition} $${targetPrice}.`
    );
  };

  const handleDeleteCustomAlert = (id: string) => {
    setUserAlerts((prev) => prev.filter((a) => a.id !== id));
    addToast("info", "ALERT CANCELLED", "Threshold tracker registration removed.");
  };

  const activeAsset = assets.find((a) => a.symbol === selectedSymbol) || assets[0];

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans antialiased overflow-x-hidden flex flex-col relative pb-16 lg:pb-0">
      
      {/* Background neon ambient textures */}
      <div className="absolute top-1/4 left-1/4 -z-10 h-96 w-96 rounded-full bg-emerald-500/5 blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 -z-10 h-96 w-96 rounded-full bg-purple-500/5 blur-[120px]" />

      {/* Floating high impact toast panels notifications overlay */}
      <div className="fixed right-4 top-4 z-50 flex flex-col gap-2 w-full max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 rounded-xl border p-4 shadow-2xl backdrop-blur-md transition-all animate-bounce [animation-duration:0.3s] ${
              toast.type === "success"
                ? "border-emerald-500 bg-zinc-950/95 shadow-emerald-500/10 text-emerald-100"
                : toast.type === "error"
                ? "border-red-500 bg-zinc-950/95 shadow-red-500/10 text-red-100"
                : toast.type === "warning"
                ? "border-amber-500 bg-zinc-950/95 shadow-amber-500/10 text-amber-100"
                : "border-zinc-800 bg-zinc-950/95 text-zinc-100"
            }`}
          >
            <span className="mt-0.5 shrink-0">
              <CircleAlert className={`h-4.5 w-4.5 ${
                toast.type === "success" ? "text-emerald-400" : toast.type === "error" ? "text-red-400" : toast.type === "warning" ? "text-amber-400" : "text-emerald-400"
              }`} />
            </span>
            <div className="flex-1 font-mono text-xs">
              <div className="font-bold border-b border-zinc-900 pb-1 mb-1 tracking-wider uppercase">
                {toast.title}
              </div>
              <p className="text-[11px] leading-relaxed text-zinc-400">{toast.text}</p>
            </div>
            
            <button
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="text-zinc-500 hover:text-white transition-colors ml-2"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>

      {/* Flagship header widget */}
      <ProfitXHeader
        balance={balance}
        onDeposit={handleWalletDeposit}
        systemAlerts={systemFeed}
        unreadAlertsCount={unreadAlertsCount}
        onClearAlertsCount={() => setUnreadAlertsCount(0)}
        activeAlertTab={() => {
          setActiveMobileTab("ALERTS");
          // Scroll on desktop to alerts section
          document.getElementById("risk_alerts_dock")?.scrollIntoView({ behavior: "smooth" });
        }}
      />

      {/* Core App Stage Body layouts */}
      <main className="flex-1 max-w-8xl w-full mx-auto p-4 lg:p-6 flex flex-col gap-5 leading-normal">
        
        {/* Desktop grid viewport - visible above md limits */}
        <div className="hidden lg:grid grid-cols-12 gap-5 items-stretch flex-1">
          
          {/* Left panel column (Width 3/12): Asset tickers & Alarm system */}
          <section className="col-span-3 flex flex-col gap-5">
            <div className="flex-1 min-h-[350px]">
              <MarketSelector
                assets={assets}
                selectedSymbol={selectedSymbol}
                onSelectAsset={(sym) => setSelectedSymbol(sym)}
              />
            </div>
            <div id="risk_alerts_dock" className="h-[280px]">
              <AlertManager
                assets={assets}
                userAlerts={userAlerts}
                onCreateAlert={handleCreateCustomAlert}
                onDeleteAlert={handleDeleteCustomAlert}
                systemFeed={systemFeed}
                soundEnabled={soundEnabled}
                onToggleSound={() => setSoundEnabled(!soundEnabled)}
              />
            </div>
          </section>

          {/* Center viewport column (Width 5/12): Candlestick Chart Engine & Win Signals */}
          <section className="col-span-5 flex flex-col gap-5">
            <div className="flex-1 min-h-[380px] h-full">
              {activeAsset ? (
                <InteractiveChart
                  symbol={selectedSymbol}
                  history={activeAsset.history}
                  currentPrice={activeAsset.currentPrice}
                />
              ) : (
                <div className="flex h-full items-center justify-center border border-zinc-900 bg-zinc-950/40 rounded-2xl">
                  <Activity className="h-8 w-8 text-zinc-700 animate-spin" />
                </div>
              )}
            </div>
            {/* Live Call/Put Analysis Gauge and Active Order Book Depth Flow */}
            {activeAsset && (
              <div className="min-h-[440px]">
                <LiveAnalysisPanel asset={activeAsset} />
              </div>
            )}
          </section>

          {/* Right viewport column (Width 4/12): High accuracy Radar Signals & Gemini Sentiment */}
          <section className="col-span-4 grid grid-rows-1 md:grid-rows-2 gap-5 leading-normal">
            
            {/* Upper half: PROFITX holographic radar signals */}
            <div className="row-span-1 h-full">
              {activeAsset && (
                <SignalAnalysis
                  asset={activeAsset}
                  activePlatform={activePlatform}
                  onChangePlatform={(plat) => setActivePlatform(plat)}
                  activeProduct={activeProduct}
                  onChangeProduct={(prod) => setActiveProduct(prod)}
                  currentSignal={currentSignal}
                  onGenerateSignal={triggerSignalGeneration}
                  isGenerating={isGeneratingSignal}
                  onExecuteMockTrade={handleExecuteMockTradeChange}
                  onAddMessage={addToast}
                  balance={balance}
                />
              )}
            </div>

            {/* Lower half: Server-Side Gemini Sentiment summaries & Global catalyst News */}
            <div className="row-span-1 h-full min-h-[290px]">
              <SentimentIntelligence
                symbol={selectedSymbol}
                sentiment={sentiment}
                onRefreshSentiment={triggerSentimentRefresh}
                isLoading={isRefreshingSentiment}
              />
            </div>

          </section>

        </div>

        {/* Adaptive Mobile Views Section (Visible under lg viewport boundaries) */}
        <div className="block lg:hidden flex-1 flex flex-col gap-4">
          {activeMobileTab === "HOME" && (
            <div className="flex flex-col gap-4">
              <div className="h-[280px]">
                <MarketSelector
                  assets={assets}
                  selectedSymbol={selectedSymbol}
                  onSelectAsset={(sym) => setSelectedSymbol(sym)}
                />
              </div>
              <div className="h-[360px]">
                {activeAsset && (
                  <InteractiveChart
                    symbol={selectedSymbol}
                    history={activeAsset.history}
                    currentPrice={activeAsset.currentPrice}
                  />
                )}
              </div>
              {/* Mobile Call and Put Live Analysis flow */}
              {activeAsset && (
                <div className="min-h-[440px]">
                  <LiveAnalysisPanel asset={activeAsset} />
                </div>
              )}
            </div>
          )}

          {activeMobileTab === "SIGNALS" && activeAsset && (
            <div className="min-h-[460px]">
              <SignalAnalysis
                asset={activeAsset}
                activePlatform={activePlatform}
                onChangePlatform={(plat) => setActivePlatform(plat)}
                activeProduct={activeProduct}
                onChangeProduct={(prod) => setActiveProduct(prod)}
                currentSignal={currentSignal}
                onGenerateSignal={triggerSignalGeneration}
                isGenerating={isGeneratingSignal}
                onExecuteMockTrade={handleExecuteMockTradeChange}
                onAddMessage={addToast}
                balance={balance}
              />
            </div>
          )}

          {activeMobileTab === "SENTIMENT" && (
            <div className="min-h-[400px]">
              <SentimentIntelligence
                symbol={selectedSymbol}
                sentiment={sentiment}
                onRefreshSentiment={triggerSentimentRefresh}
                isLoading={isRefreshingSentiment}
              />
            </div>
          )}

          {activeMobileTab === "ALERTS" && (
            <div className="min-h-[380px]">
              <AlertManager
                assets={assets}
                userAlerts={userAlerts}
                onCreateAlert={handleCreateCustomAlert}
                onDeleteAlert={handleDeleteCustomAlert}
                systemFeed={systemFeed}
                soundEnabled={soundEnabled}
                onToggleSound={() => setSoundEnabled(!soundEnabled)}
              />
            </div>
          )}
        </div>

      </main>

      {/* Adaptive Mobile Dock Tabbar (Visible under lg breakpoints matching screenshotfooter) */}
      <footer className="lg:hidden fixed bottom-0 inset-x-0 bg-zinc-950/95 border-t border-zinc-800 z-40 backdrop-blur-md px-3 py-1 flex items-center justify-around h-16 font-mono">
        <button
          onClick={() => setActiveMobileTab("HOME")}
          className={`flex flex-col items-center justify-center gap-1.5 py-1 px-3.5 transition-all text-center ${
            activeMobileTab === "HOME"
              ? "text-emerald-400 font-bold"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <Activity className="h-5 w-5" />
          <span className="text-[9px] uppercase tracking-wider">CHARTS</span>
        </button>

        <button
          onClick={() => setActiveMobileTab("SIGNALS")}
          className={`flex flex-col items-center justify-center gap-1.5 py-1 px-3.5 transition-all text-center ${
            activeMobileTab === "SIGNALS"
              ? "text-emerald-400 font-bold"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <Award className="h-5 w-5" />
          <span className="text-[9px] uppercase tracking-wider">SIGNALS</span>
        </button>

        <button
          onClick={() => setActiveMobileTab("SENTIMENT")}
          className={`flex flex-col items-center justify-center gap-1.5 py-1 px-3.5 transition-all text-center ${
            activeMobileTab === "SENTIMENT"
              ? "text-emerald-400 font-bold"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <Sparkles className="h-5 w-5" />
          <span className="text-[9px] uppercase tracking-wider">INTEL</span>
        </button>

        <button
          onClick={() => setActiveMobileTab("ALERTS")}
          className={`flex flex-col items-center justify-center gap-1.5 py-1 px-3.5 transition-all text-center ${
            activeMobileTab === "ALERTS"
              ? "text-emerald-400 font-bold"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <div className="relative">
            <Bell className="h-5 w-5" />
            {unreadAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-emerald-500"></span>
            )}
          </div>
          <span className="text-[9px] uppercase tracking-wider">ALERTS</span>
        </button>
      </footer>

    </div>
  );
}
