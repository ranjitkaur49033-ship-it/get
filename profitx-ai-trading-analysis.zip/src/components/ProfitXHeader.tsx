import React, { useState, useEffect } from "react";
import { Wallet, Bell, Flame, Plus, Clock, Globe } from "lucide-react";
import { SystemFeedAlert } from "../types";

interface ProfitXHeaderProps {
  balance: number;
  onDeposit: (amount: number) => void;
  systemAlerts: SystemFeedAlert[];
  unreadAlertsCount: number;
  onClearAlertsCount: () => void;
  activeAlertTab: () => void;
}

export default function ProfitXHeader({
  balance,
  onDeposit,
  systemAlerts,
  unreadAlertsCount,
  onClearAlertsCount,
  activeAlertTab,
}: ProfitXHeaderProps) {
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositAmount, setDepositAmount] = useState("1000");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showAlertDropdown, setShowAlertDropdown] = useState(false);

  // Tick clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(depositAmount);
    if (!isNaN(val) && val > 0) {
      onDeposit(val);
      setShowDepositModal(false);
    }
  };

  return (
    <header className="relative w-full border-b border-zinc-800 bg-zinc-950/80 px-4 py-4 backdrop-blur-md lg:px-8">
      {/* Top row */}
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 md:flex-row">
        
        {/* Branding (Left/Center representation matching screenshot) */}
        <div className="flex flex-col items-center gap-1 md:items-start">
          <div className="flex items-center gap-3">
            {/* Pulsing Neon Orb Icon */}
            <div className="relative flex h-10 w-10 items-center justify-center rounded-full border border-emerald-500 bg-zinc-900 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
              <div className="absolute inset-0 rounded-full border border-emerald-400 border-dashed animate-radar opacity-70"></div>
              <Globe className="h-5 w-5 text-emerald-400 animate-pulse" />
              <div className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-500"></div>
            </div>
            
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="font-display text-2xl font-bold tracking-wider text-white">
                  PROFIT<span className="text-emerald-400 glow-green-text">X</span>
                </span>
                <span className="rounded bg-emerald-500/10 px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-widest text-emerald-400 border border-emerald-500/20">
                  AI SIGNAL ENGINE
                </span>
              </div>
              <span className="font-display text-[9px] tracking-[0.25em] text-zinc-400 uppercase">
                QUANTITATIVE MULTI-STRATEGY PIPELINE
              </span>
            </div>
          </div>
        </div>

        {/* Real-time Ticker & Metrics (Center) */}
        <div className="hidden items-center gap-4 text-xs font-mono text-zinc-400 md:flex">
          <div className="flex items-center gap-1.5 border-r border-zinc-800 pr-4">
            <Clock className="h-3.5 w-3.5 text-emerald-400" />
            <span>UTC: {currentTime.toISOString().substring(11, 19)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Flame className="h-3.5 w-3.5 text-yellow-500" />
            <span className="text-zinc-300">SERVER LATENCY: <span className="text-emerald-400 font-bold">14ms</span></span>
          </div>
        </div>

        {/* Balance & Actions (Right) */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          
          {/* Main Account Balance Display matching the target screen exactly */}
          <div className="flex items-center gap-3 rounded-lg border border-zinc-800 bg-zinc-900/60 p-2 px-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-emerald-500/10 text-emerald-400">
              <Wallet className="h-4.5 w-4.5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-medium tracking-wider text-zinc-400 uppercase">ACCOUNT BALANCE</span>
              <span className="font-display text-lg font-bold tracking-tight text-white glow-green-text">
                ${balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            
            {/* Quick Deposit Trigger */}
            <button
              onClick={() => setShowDepositModal(true)}
              id="header_deposit_btn"
              className="ml-2 flex items-center gap-1 rounded bg-emerald-500 px-3 py-1.5 font-display text-xs font-bold text-black shadow-lg shadow-emerald-500/20 transition-all hover:bg-emerald-400 hover:scale-105 active:scale-95"
            >
              <Plus className="h-3 w-3 stroke-[3px]" />
              Deposit
            </button>
          </div>

          {/* Alert Notification bell */}
          <div className="relative">
            <button
              onClick={() => {
                setShowAlertDropdown(!showAlertDropdown);
                onClearAlertsCount();
              }}
              id="header_alert_bell"
              className={`relative flex h-10 w-10 items-center justify-center rounded-full border bg-zinc-900 transition-colors ${
                unreadAlertsCount > 0 
                  ? "border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/20" 
                  : "border-zinc-800 text-zinc-400 hover:bg-zinc-800/50"
              }`}
            >
              <Bell className="h-4.5 w-4.5" />
              {unreadAlertsCount > 0 && (
                <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 font-mono text-[9px] font-bold text-black">
                  {unreadAlertsCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showAlertDropdown && (
              <div className="absolute right-0 z-50 mt-2 w-80 rounded-xl border border-zinc-800 bg-zinc-950 p-4 shadow-2xl">
                <div className="mb-2 flex items-center justify-between border-b border-zinc-800 pb-2">
                  <h4 className="font-display text-xs font-bold text-white uppercase tracking-wider">SYSTEM LOGS</h4>
                  <button 
                    onClick={() => {
                      activeAlertTab();
                      setShowAlertDropdown(false);
                    }} 
                    className="text-[10px] text-emerald-400 underline hover:text-emerald-300"
                  >
                    View All
                  </button>
                </div>
                
                <div className="flex max-h-60 flex-col gap-2 overflow-y-auto">
                  {systemAlerts.slice(0, 4).map((alert) => (
                    <div 
                      key={alert.id} 
                      className={`rounded p-2 text-xs border ${
                        alert.severity === "high" 
                          ? "bg-red-500/5 border-red-500/20 text-red-200" 
                          : alert.severity === "medium"
                          ? "bg-amber-500/5 border-amber-500/20 text-amber-200"
                          : "bg-zinc-900/40 border-zinc-800 text-zinc-300"
                      }`}
                    >
                      <div className="flex justify-between font-mono text-[9px] text-zinc-500 mb-1">
                        <span>{alert.symbol}</span>
                        <span>{alert.time}</span>
                      </div>
                      <p>{alert.message}</p>
                    </div>
                  ))}
                  {systemAlerts.length === 0 && (
                    <p className="py-4 text-center text-xs text-zinc-500">No recent market alerts.</p>
                  )}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Deposit Modal */}
      {showDepositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-950 p-6 shadow-2xl">
            <h3 className="mb-1 font-display text-lg font-bold text-white uppercase tracking-wider">FUND DEMO ACCOUNT</h3>
            <p className="mb-4 text-xs text-zinc-500">Add virtual funds to test signals across binary expirates.</p>
            
            <form onSubmit={handleDepositSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5 font-mono">
                <label className="text-[10px] uppercase text-zinc-400">AMOUT TO FUND ($)</label>
                <input
                  type="number"
                  required
                  min="10"
                  max="100000"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-2.5 font-display text-xl font-bold text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              {/* Preselected helper buttons */}
              <div className="grid grid-cols-4 gap-2">
                {["500", "1000", "5000", "10000"].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setDepositAmount(preset)}
                    className="rounded border border-zinc-800 bg-zinc-900/30 py-1.5 font-mono text-xs text-zinc-300 hover:border-emerald-500 hover:text-emerald-400 transition-colors"
                  >
                    +${preset}
                  </button>
                ))}
              </div>

              <div className="mt-2 flex justify-end gap-3 text-xs font-medium">
                <button
                  type="button"
                  onClick={() => setShowDepositModal(false)}
                  className="rounded px-4 py-2 text-zinc-400 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-emerald-500 px-5 py-2 font-display font-bold text-black transition-all hover:bg-emerald-400"
                >
                  Confirm Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
}
