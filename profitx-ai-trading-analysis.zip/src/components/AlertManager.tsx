import React, { useState } from "react";
import { AlertCircle, AlertTriangle, TrendingUp, TrendingDown, Bell, Plus, Trash2, ShieldCheck, Volume2, VolumeX } from "lucide-react";
import { PriceAlert, SystemFeedAlert, Asset } from "../types";

interface AlertManagerProps {
  assets: Asset[];
  userAlerts: PriceAlert[];
  onCreateAlert: (symbol: string, targetPrice: number, condition: "ABOVE" | "BELOW") => void;
  onDeleteAlert: (id: string) => void;
  systemFeed: SystemFeedAlert[];
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export default function AlertManager({
  assets,
  userAlerts,
  onCreateAlert,
  onDeleteAlert,
  systemFeed,
  soundEnabled,
  onToggleSound,
}: AlertManagerProps) {
  const [selectedSymbol, setSelectedSymbol] = useState(assets[0]?.symbol || "EUR/USD");
  const [targetPrice, setTargetPrice] = useState("");
  const [condition, setCondition] = useState<"ABOVE" | "BELOW">("ABOVE");

  const asset = assets.find((a) => a.symbol === selectedSymbol);
  const currentPrice = asset ? asset.currentPrice : 0;
  const priceDecimal = selectedSymbol.includes("JPY") || selectedSymbol.includes("BTC") ? 2 : 4;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(targetPrice);
    if (!isNaN(priceNum) && priceNum > 0) {
      onCreateAlert(selectedSymbol, priceNum, condition);
      setTargetPrice("");
    }
  };

  const handleQuickSetter = (percentChange: number) => {
    if (!currentPrice) return;
    const offset = currentPrice * (percentChange / 100);
    const calculated = currentPrice + offset;
    setTargetPrice(calculated.toFixed(priceDecimal));
    setCondition(percentChange >= 0 ? "ABOVE" : "BELOW");
  };

  return (
    <div className="flex flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl h-full font-mono">
      {/* Upper header action blocks */}
      <div className="mb-4 flex items-center justify-between border-b border-zinc-900 pb-3">
        <div className="flex items-center gap-1.5">
          <Bell className="h-4.5 w-4.5 text-emerald-400 animate-pulse" />
          <h3 className="font-display text-sm font-bold text-white tracking-widest uppercase">
            FLUCTUATION ALERTS
          </h3>
        </div>

        {/* Audio chime alerts control */}
        <button
          onClick={onToggleSound}
          id="toggle_sound_btn"
          className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-all ${
            soundEnabled
              ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400"
              : "border-zinc-800 bg-zinc-900/30 text-zinc-500"
          }`}
          title={soundEnabled ? "Chime Muted" : "Chime Enabled"}
        >
          {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>
      </div>

      {/* Grid containing alert registration and active alerts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Left Column: Form creator */}
        <div className="rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5">
          <h4 className="mb-3 font-display text-xs font-bold text-white uppercase tracking-wider text-zinc-400">
            CREATE CUSTOM RISK ALERT
          </h4>
          
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-2">
              {/* Asset Selector */}
              <div className="flex flex-col gap-1">
                <label className="text-[9px] text-zinc-500 font-bold uppercase">INSTRUMENT</label>
                <select
                  value={selectedSymbol}
                  onChange={(e) => {
                    setSelectedSymbol(e.target.value);
                    const matched = assets.find((a) => a.symbol === e.target.value);
                    if (matched) setTargetPrice(matched.currentPrice.toFixed(matched.symbol.includes("JPY") || matched.symbol.includes("BTC") ? 2 : 4));
                  }}
                  className="rounded border border-zinc-800 bg-zinc-950 p-2 font-mono text-xs text-white focus:border-emerald-500 focus:outline-none"
                >
                  {assets.map((a) => (
                    <option key={a.symbol} value={a.symbol}>
                      {a.symbol}
                    </option>
                  ))}
                </select>
              </div>

              {/* Condition above or below */}
              <div className="flex flex-col gap-1">
                <label className="text-[9px] text-zinc-500 font-bold uppercase">CONDITION</label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value as "ABOVE" | "BELOW")}
                  className="rounded border border-zinc-800 bg-zinc-950 p-2 font-mono text-xs text-white focus:border-emerald-500 focus:outline-none"
                >
                  <option value="ABOVE">BREACH ABOVE (↗)</option>
                  <option value="BELOW">SLIDE BELOW (↘)</option>
                </select>
              </div>
            </div>

            {/* Target price input */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[9px] text-zinc-500 font-bold">
                <span className="uppercase">TARGET PRICES</span>
                <span>CURR: {currentPrice.toFixed(priceDecimal)}</span>
              </div>
              <input
                type="number"
                step="any"
                required
                placeholder="Target price threshhold..."
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                className="rounded border border-zinc-800 bg-zinc-950 p-2 text-xs text-white placeholder-zinc-700 focus:border-emerald-500 focus:outline-none font-bold"
              />
            </div>

            {/* Quick target percentage triggers */}
            <div className="grid grid-cols-4 gap-1">
              {[-1, -0.2, 0.2, 1].map((pct) => (
                <button
                  type="button"
                  key={pct}
                  onClick={() => handleQuickSetter(pct)}
                  className={`rounded border py-1 text-[9px] font-bold tracking-tight transition-all ${
                    pct < 0 
                      ? "border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/10" 
                      : "border-emerald-500/20 bg-emerald-500/5 text-emerald-400 hover:bg-emerald-500/10"
                  }`}
                >
                  {pct > 0 ? "+" : ""}{pct}%
                </button>
              ))}
            </div>

            <button
              type="submit"
              id="alert_create_submit"
              className="mt-1 flex items-center justify-center gap-1.5 rounded bg-emerald-500 p-2 font-display text-xs font-bold text-black border border-transparent shadow shadow-emerald-500/10 hover:bg-emerald-400 active:scale-95 transition-all"
            >
              <Plus className="h-3.5 w-3.5 stroke-[2.5px]" />
              ACTIVATE CRITICAL TRACKER
            </button>
          </form>
        </div>

        {/* Right Column: User Alerts Trackers */}
        <div className="flex flex-col rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5">
          <h4 className="mb-3 font-display text-xs font-bold text-white uppercase tracking-wider text-zinc-400 flex justify-between">
            <span>ACTIVE ALARM REGISTERS</span>
            <span className="rounded bg-zinc-800 p-1 px-1.5 text-[8px] text-zinc-500">
              {userAlerts.length} REGISTERED
            </span>
          </h4>

          <div className="flex-1 overflow-y-auto max-h-44 space-y-1.5 pr-1">
            {userAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`flex items-center justify-between rounded-lg border p-2 text-xs leading-normal transition-all ${
                  alert.triggered
                    ? "border-emerald-500/20 bg-emerald-500/5 opacity-60"
                    : "border-zinc-800 bg-zinc-950"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`inline-block rounded p-1 text-[9px] font-bold leading-none ${
                    alert.condition === "ABOVE" 
                      ? "bg-emerald-500/10 text-emerald-400" 
                      : "bg-red-500/10 text-red-400"
                  }`}>
                    {alert.condition === "ABOVE" ? "↗ ABOVE" : "↘ BELOW"}
                  </span>
                  <div>
                    <span className="font-bold text-white">{alert.symbol}</span>
                    <span className="mx-1.5 text-zinc-600">at</span>
                    <span className="font-bold text-zinc-300">
                      {alert.targetPrice.toFixed(alert.symbol.includes("JPY") || alert.symbol.includes("BTC") ? 2 : 4)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {alert.triggered ? (
                    <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                      <ShieldCheck className="h-3.5 w-3.5" />
                      TRIGGERED
                    </span>
                  ) : (
                    <button
                      onClick={() => onDeleteAlert(alert.id)}
                      className="rounded p-1 text-zinc-600 hover:bg-zinc-900 hover:text-red-400 transition-colors"
                      title="Delete alert"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}

            {userAlerts.length === 0 && (
              <div className="py-8 text-center text-xs text-zinc-600">
                No active threshold alarms.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Historical System Alerts stream (Fluctuation Log) */}
      <div className="mt-4 flex-1 border-t border-zinc-900 pt-3">
        <h4 className="mb-2 font-display text-xs font-bold text-white uppercase tracking-wider text-zinc-400">
          AUTOMATED MARKET FLUCTUATIONS STREAM
        </h4>
        <div className="space-y-1.5 overflow-y-auto max-h-40 pr-1">
          {systemFeed.map((alert) => (
            <div
              key={alert.id}
              className={`flex items-start gap-2.5 rounded border p-2 text-xs transition-all ${
                alert.severity === "high"
                  ? "border-red-500/20 bg-red-950/15 text-red-200"
                  : alert.severity === "medium"
                  ? "border-amber-500/20 bg-amber-950/15 text-amber-200"
                  : "border-zinc-800 bg-zinc-900/30 text-zinc-300"
              }`}
            >
              <span className="mt-0.5 shrink-0">
                {alert.severity === "high" ? (
                  <AlertCircle className="h-4 w-4 text-red-400" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-amber-400" />
                )}
              </span>
              <div className="flex-1">
                <div className="flex items-center justify-between font-bold leading-none mb-1">
                  <span className={alert.severity === "high" ? "text-red-400" : alert.severity === "medium" ? "text-amber-400" : "text-zinc-400"}>
                    {alert.symbol} FLUID WARNING
                  </span>
                  <span className="font-mono text-[9px] text-zinc-500">{alert.time}</span>
                </div>
                <p className="text-[11px] leading-relaxed text-zinc-400">{alert.message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
