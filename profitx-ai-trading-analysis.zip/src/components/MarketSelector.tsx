import { useState } from "react";
import { Search, Flame, DollarSign, TrendingUp, TrendingDown } from "lucide-react";
import { Asset } from "../types";

interface MarketSelectorProps {
  assets: Asset[];
  selectedSymbol: string;
  onSelectAsset: (symbol: string) => void;
}

export default function MarketSelector({
  assets,
  selectedSymbol,
  onSelectAsset,
}: MarketSelectorProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<"All" | "Forex" | "Crypto" | "Stocks/Commodities">("All");

  const filteredAssets = assets.filter((asset) => {
    // Search match
    const matchesSearch =
      asset.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category match
    if (categoryFilter === "All") return matchesSearch;
    if (categoryFilter === "Forex") return matchesSearch && asset.category === "Forex";
    if (categoryFilter === "Crypto") return matchesSearch && asset.category === "Crypto";
    if (categoryFilter === "Stocks/Commodities") {
      return matchesSearch && (asset.category === "Stocks" || asset.category === "Commodities");
    }
    return matchesSearch;
  });

  // Small inline helper to generate sparkline path based on history close values
  const getSparklinePoints = (historyClose: number[]): string => {
    if (historyClose.length < 2) return "";
    const min = Math.min(...historyClose);
    const max = Math.max(...historyClose);
    const range = max - min === 0 ? 1 : max - min;
    const height = 24;
    const width = 80;
    const step = width / (historyClose.length - 1);
    
    return historyClose
      .map((val, idx) => {
        const x = idx * step;
        const y = height - ((val - min) / range) * height;
        return `${x},${y}`;
      })
      .join(" ");
  };

  return (
    <div className="flex h-full flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl">
      {/* Search Bar */}
      <div className="relative mb-4">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500">
          <Search className="h-4 w-4" />
        </span>
        <input
          type="text"
          placeholder="SEARCH TRADING PAIRS..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full rounded-lg border border-zinc-800 bg-zinc-900/40 py-2 pl-9 pr-4 font-mono text-xs text-white placeholder-zinc-500 focus:border-emerald-500/80 focus:outline-none"
        />
      </div>

      {/* Category Tabs */}
      <div className="mb-4 flex gap-1 rounded-lg bg-zinc-900/40 p-1">
        {(["All", "Forex", "Crypto", "Stocks/Commodities"] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`flex-1 rounded py-1.5 font-display text-[10px] font-bold tracking-wider uppercase transition-all ${
              categoryFilter === cat
                ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/10"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            {cat === "Stocks/Commodities" ? "Stocks / Commodities" : cat}
          </button>
        ))}
      </div>

      {/* Active Tickers Header list */}
      <div className="mb-2 grid grid-cols-12 px-2 text-[10px] font-mono font-bold tracking-widest text-zinc-500 uppercase">
        <span className="col-span-5">INSTRUMENT</span>
        <span className="col-span-4 text-right">LIVE PRICE</span>
        <span className="col-span-3 text-right">CHANGE</span>
      </div>

      {/* Active List */}
      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
        {filteredAssets.map((asset) => {
          const isSelected = asset.symbol === selectedSymbol;
          const isUp = asset.changePercent >= 0;
          const priceDecimal = asset.symbol.includes("JPY") || asset.symbol.includes("BTC") ? 2 : 4;
          const closePrices = asset.history.map((h) => h.close);

          return (
            <button
              key={asset.symbol}
              onClick={() => onSelectAsset(asset.symbol)}
              className={`group flex w-full flex-col rounded-xl border p-3 transition-all ${
                isSelected
                  ? "border-emerald-500 bg-emerald-950/10 glow-green-sm"
                  : "border-zinc-900 bg-zinc-900/20 hover:border-zinc-850 hover:bg-zinc-800/20"
              }`}
            >
              <div className="grid w-full grid-cols-12 items-center">
                {/* Ticker Name */}
                <div className="col-span-5 flex flex-col items-start leading-snug">
                  <div className="flex items-center gap-1.5">
                    <span className="font-display text-sm font-bold text-white tracking-wide">
                      {asset.symbol}
                    </span>
                    {asset.symbol === "BTC/USD" && (
                      <Flame className="h-3 w-3 text-amber-500 animate-pulse" />
                    )}
                  </div>
                  <span className="font-mono text-[9px] text-zinc-500 truncate max-w-[100px]">
                    {asset.name}
                  </span>
                </div>

                {/* Sparkline trend vector */}
                <div className="col-span-4 flex justify-end pr-2">
                  <svg className="h-6 w-20 overflow-visible">
                    <polyline
                      fill="none"
                      stroke={isUp ? "#10b981" : "#ef4444"}
                      strokeWidth="1.5"
                      points={getSparklinePoints(closePrices)}
                    />
                  </svg>
                </div>

                {/* Price Display */}
                <div className="col-span-3 flex flex-col items-end">
                  <span className="font-mono text-xs font-bold text-white tracking-tight">
                    {asset.currentPrice.toFixed(priceDecimal)}
                  </span>
                  <span
                    className={`font-mono text-[9px] font-semibold flex items-center ${
                      isUp ? "text-emerald-400" : "text-red-400"
                    }`}
                  >
                    {isUp ? (
                      <TrendingUp className="mr-0.5 h-2.5 w-2.5" />
                    ) : (
                      <TrendingDown className="mr-0.5 h-2.5 w-2.5" />
                    )}
                    {isUp ? "+" : ""}
                    {asset.changePercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            </button>
          );
        })}

        {filteredAssets.length === 0 && (
          <div className="py-12 text-center text-xs text-zinc-500">
            No matching trade instruments found.
          </div>
        )}
      </div>
    </div>
  );
}
