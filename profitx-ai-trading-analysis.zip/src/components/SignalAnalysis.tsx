import React, { useState, useEffect } from "react";
import { Radar, Hourglass, Activity, Flame, Shield, TrendingUp, TrendingDown, RefreshCw, Layers } from "lucide-react";
import { AISignal, Asset } from "../types";

interface SignalAnalysisProps {
  asset: Asset;
  activePlatform: string;
  onChangePlatform: (plat: string) => void;
  activeProduct: "LIVE" | "OTC";
  onChangeProduct: (prod: "LIVE" | "OTC") => void;
  currentSignal: AISignal | null;
  onGenerateSignal: () => Promise<void>;
  isGenerating: boolean;
  onExecuteMockTrade: (stakeAmount: number, direction: "CALL" | "PUT", durationSeconds: number) => void;
  onAddMessage: (type: "success" | "error" | "info" | "warning", title: string, text: string) => void;
  balance: number;
}

export default function SignalAnalysis({
  asset,
  activePlatform,
  onChangePlatform,
  activeProduct,
  onChangeProduct,
  currentSignal,
  onGenerateSignal,
  isGenerating,
  onExecuteMockTrade,
  onAddMessage,
  balance,
}: SignalAnalysisProps) {
  const [stakeAmount, setStakeAmount] = useState("100");
  const [activeExecBlocks, setActiveExecBlocks] = useState<Array<{
    id: string;
    symbol: string;
    direction: "CALL" | "PUT";
    stake: number;
    timeLeft: number;
    entryPrice: number;
  }>>([]);

  // Mock Platforms matching reference exactly
  const platforms = ["QUOTEX", "POCKET OPTION", "OLYMP TRADE", "BINOMO"];

  // Secondary tick runner for execution timers
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveExecBlocks((prev) => {
        const next: typeof prev = [];
        prev.forEach((t) => {
          if (t.timeLeft <= 1) {
            // Trade expired! Calculate win/loss based on random direction + signal bias
            const isWin = Math.random() < 0.68; // 68% Win rate mimicking accurate signal indicator
            const payout = isWin ? Math.floor(t.stake * 1.85) : 0;
            const diff = payout - t.stake;

            onExecuteMockTrade(diff, t.direction, 0);

            if (isWin) {
              onAddMessage(
                "success",
                "TRADE EXPIRED: WIN",
                `${t.symbol} ${t.direction} expired in-the-money! Received payout of $${payout.toFixed(2)} (+85% profit).`
              );
            } else {
              onAddMessage(
                "error",
                "TRADE EXPIRED: LOSS",
                `${t.symbol} ${t.direction} expired out-of-the-money. Lost stake of $${t.stake.toFixed(2)}.`
              );
            }
          } else {
            next.push({ ...t, timeLeft: t.timeLeft - 1 });
          }
        });
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeExecBlocks, onExecuteMockTrade, onAddMessage]);

  const handlePlaceTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const stakeNum = parseFloat(stakeAmount);
    if (isNaN(stakeNum) || stakeNum <= 0) {
      onAddMessage("warning", "INVALID STAKE", "Please input a positive stake wager.");
      return;
    }
    if (stakeNum > balance) {
      onAddMessage("error", "INSUFFICIENT BALANCE", "You do not have enough demo balance to place this trade.");
      return;
    }
    if (!currentSignal) {
      onAddMessage("warning", "NO SIGNAL GENERATED", "Please generate an AI signal prior to trade executions.");
      return;
    }

    // Deduct initial stake immediately
    onExecuteMockTrade(-stakeNum, currentSignal.direction, 0);

    // Register countdown block
    const newBlock = {
      id: Math.random().toString(),
      symbol: asset.symbol,
      direction: currentSignal.direction,
      stake: stakeNum,
      timeLeft: currentSignal.expiry.includes("15") ? 60 : (currentSignal.expiry.includes("5") ? 25 : 10), // mock seconds for demo speeds
      entryPrice: asset.currentPrice,
    };

    setActiveExecBlocks((prev) => [...prev, newBlock]);
    onAddMessage(
      "info",
      "TRADE EXECUTED",
      `Placed $${stakeNum} on ${asset.symbol} ${currentSignal.direction} (${currentSignal.expiry} contract).`
    );
  };

  return (
    <div className="flex h-full flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl select-none">
      
      {/* 1. Platforms Container row mockup */}
      <div className="mb-4">
        <label className="mb-2 block font-mono text-[9px] font-bold uppercase tracking-wider text-zinc-500">
          SELECT TRADING TERMINAL PLATFORM
        </label>
        <div className="grid grid-cols-2 gap-2">
          {platforms.map((p) => {
            const isActive = activePlatform === p;
            return (
              <button
                key={p}
                onClick={() => onChangePlatform(p)}
                className={`rounded-xl border p-2.5 font-display text-xs font-bold transition-all flex items-center justify-between uppercase ${
                  isActive
                    ? "border-emerald-500 bg-emerald-950/15 text-white shadow-[0_0_12px_rgba(16,185,129,0.15)]"
                    : "border-zinc-900 bg-zinc-900/40 text-zinc-400 hover:border-zinc-800 hover:text-white"
                }`}
              >
                <span>{p}</span>
                {isActive && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. LIVE / OTC Switch */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <label className="font-mono text-[9px] font-bold uppercase tracking-wider text-zinc-500">
            CONTRACT PRODUCT TYPE
          </label>
          <span className="font-mono text-[9px] text-zinc-600 font-bold">MODE MODEL</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {(["LIVE", "OTC"] as const).map((mode) => {
            const isActive = activeProduct === mode;
            return (
              <button
                key={mode}
                onClick={() => onChangeProduct(mode)}
                className={`rounded-xl border py-2 px-3 font-display text-xs font-bold transition-all uppercase flex items-center justify-center gap-1.5 ${
                  isActive
                    ? "border-emerald-500 bg-emerald-950/15 text-white glow-green-sm"
                    : "border-zinc-900 bg-zinc-900/40 text-zinc-400 hover:text-white"
                }`}
              >
                {isActive && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>}
                <span>{mode} MARKET</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Action Scan Trigger */}
      <button
        onClick={onGenerateSignal}
        disabled={isGenerating}
        id="generate_signal_trigger"
        className={`relative mb-4 flex w-full items-center justify-center gap-2 rounded-xl py-3.5 font-display text-[13px] font-bold uppercase text-black transition-all ${
          isGenerating
            ? "bg-zinc-800 text-zinc-400 cursor-not-allowed"
            : "bg-emerald-500 hover:bg-emerald-400 shadow-md shadow-emerald-500/20 active:scale-95"
        }`}
      >
        {isGenerating ? (
          <>
            <RefreshCw className="h-4.5 w-4.5 animate-spin duration-700" />
            SCANNING BLOCKCHAIN LIQUIDITY POOLS...
          </>
        ) : (
          <>
            <Radar className="h-4.5 w-4.5" />
            GENERATE AI TRADE SIGNAL
          </>
        )}
      </button>

      {/* 3. Main Signal Hologram Indicator Ring Container */}
      <div className="flex-1 rounded-2xl border border-zinc-900 bg-zinc-900/10 p-4 flex flex-col justify-center relative min-h-[220px]">
        {isGenerating ? (
          <div className="flex flex-col items-center justify-center py-8">
            <div className="relative flex h-24 w-24 items-center justify-center rounded-full border-4 border-emerald-500/10 mb-4">
              <div className="absolute inset-0 rounded-full border-2 border-emerald-500 border-dashed animate-radar"></div>
              <div className="h-6 w-6 rounded-full bg-emerald-500/30 animate-ping"></div>
              <Layers className="absolute h-8 w-8 text-emerald-400" />
            </div>
            <span className="font-mono text-xs font-bold text-emerald-400 tracking-widest uppercase animate-pulse">
              ANALYZING QUANT CANDLES...
            </span>
          </div>
        ) : currentSignal ? (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            
            {/* Embedded Left radar ring display */}
            <div className="md:col-span-4 flex justify-center">
              <div className="relative flex h-32 w-32 items-center justify-center rounded-full border border-zinc-800 bg-zinc-950/60 shadow-[0_0_20px_rgba(16,185,129,0.06)]">
                
                {/* Simulated outer orbiting nodes */}
                <div className="absolute inset-2.5 rounded-full border border-emerald-500/30 border-dotted animate-radar"></div>
                <div className="absolute inset-6 rounded-full border border-emerald-500/10 animate-pulse-ring"></div>
                
                {/* Flags/Symbol core display */}
                <div className="flex flex-col items-center text-center">
                  <span className="font-display text-sm font-black text-white glow-green-text leading-tight">
                    {currentSignal.symbol}
                  </span>
                  <span className="font-mono text-[8px] text-zinc-500 uppercase font-medium mt-1">
                    TARGET PAIR
                  </span>
                </div>
              </div>
            </div>

            {/* Right Signal Parameters */}
            <div className="md:col-span-8 flex flex-col justify-center leading-normal">
              
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-mono text-[10px] text-zinc-500 font-bold uppercase">SIGNAL DIRECTION</span>
                <span className="rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[8px] font-bold text-emerald-400 uppercase tracking-widest">
                  Highly Accurate
                </span>
              </div>

              {/* Huge Direction Bias */}
              <div className="flex items-center gap-3.5 mb-2.5">
                <span className={`font-display text-4xl font-extrabold tracking-wide leading-none ${
                  currentSignal.direction === "CALL" ? "text-emerald-400 glow-green-text" : "text-red-400"
                }`}>
                  {currentSignal.direction}
                </span>
                <div>
                  {currentSignal.direction === "CALL" ? (
                    <TrendingUp className="h-9 w-9 text-emerald-400 animate-bounce" />
                  ) : (
                    <TrendingDown className="h-9 w-9 text-red-400 animate-bounce" />
                  )}
                </div>
              </div>

              {/* Confidence bars */}
              <div className="mb-4">
                <div className="flex justify-between font-mono text-[9px] font-bold text-zinc-400 mb-1">
                  <span>CONFIDENCE RATINGS</span>
                  <span className="text-emerald-400 font-bold">{currentSignal.confidence}%</span>
                </div>
                
                {/* Pixelated progress meter */}
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, idx) => {
                    const threshold = (idx + 1) * 10;
                    const isActive = currentSignal.confidence >= threshold;
                    return (
                      <div
                        key={idx}
                        className={`flex-1 h-2 rounded-sm transition-all ${
                          isActive 
                            ? "bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.5)]" 
                            : "bg-zinc-900"
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Parameters metrics list in footer */}
              <div className="grid grid-cols-2 gap-y-2.5 gap-x-4 border-t border-zinc-900 pt-3 text-[10px] font-mono">
                <div className="flex items-center gap-2">
                  <span className="text-zinc-500"><Hourglass className="h-3.5 w-3.5" /></span>
                  <span className="text-zinc-400 uppercase">EXPIRY: <span className="text-white font-bold">{currentSignal.expiry}</span></span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-zinc-500"><Activity className="h-3.5 w-3.5" /></span>
                  <span className="text-zinc-400 uppercase">STRENGTH: <span className="text-white font-bold">{currentSignal.strength}</span></span>
                </div>
                <div className="flex items-center gap-2 col-span-2">
                  <span className="text-zinc-500"><Shield className="h-3.5 w-3.5" /></span>
                  <span className="text-zinc-400 uppercase">CONFIDENCE STABILITY: <span className="text-emerald-400 font-bold">{currentSignal.accuracyRating}</span></span>
                </div>
              </div>

            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-center leading-normal">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-full border border-dashed border-zinc-800 bg-zinc-900/30 text-zinc-500 mb-3">
              <Radar className="h-6 w-6" />
            </div>
            <h4 className="font-display text-sm font-bold text-white uppercase tracking-wider mb-1">
              Engine Hot & Ready
            </h4>
            <p className="max-w-xs text-[11px] text-zinc-500">
              Select your platform and configuration options, then prompt or click the trigger to gather instant algorithmic CALL/PUT bias signals.
            </p>
          </div>
        )}
      </div>

      {/* 4. Active bets execution pad overlay */}
      {currentSignal && !isGenerating && (
        <div className="mt-4 border-t border-zinc-900 pt-3">
          <h4 className="mb-2 font-display text-xs font-bold text-white uppercase tracking-wider text-zinc-400">
            SIMULATOR CONTRACT BET PAD
          </h4>
          
          <form onSubmit={handlePlaceTrade} className="flex gap-2 font-mono items-end">
            <div className="flex flex-col gap-1 flex-1">
              <label className="text-[8px] text-zinc-500 uppercase font-bold">WAGER DEMO STAKE ($)</label>
              <input
                type="number"
                min="5"
                max="10000"
                value={stakeAmount}
                onChange={(e) => setStakeAmount(e.target.value)}
                className="rounded border border-zinc-800 bg-zinc-950 p-1.5 text-xs text-white uppercase font-bold focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              id="bet_submit_btn"
              className={`rounded px-4 py-2 font-display text-xs font-bold uppercase transition-all ${
                currentSignal.direction === "CALL"
                  ? "bg-emerald-500 text-black hover:bg-emerald-450"
                  : "bg-red-500 text-white hover:bg-red-450"
              }`}
            >
              EXECUTE {currentSignal.direction}
            </button>
          </form>

          {/* Active Contract block trackers */}
          {activeExecBlocks.length > 0 && (
            <div className="mt-3.5 space-y-1.5">
              <label className="block text-[8px] font-bold text-zinc-500 uppercase tracking-widest">
                ACTIVE CONTRACT COUNTDOWNS
              </label>
              {activeExecBlocks.map((block) => (
                <div
                  key={block.id}
                  className="flex items-center justify-between rounded bg-zinc-900/60 p-2 text-xs border border-zinc-800"
                >
                  <div className="flex items-center gap-2">
                    <span className={`inline-block rounded px-1.5 py-0.5 text-[8.5px] font-bold ${
                      block.direction === "CALL" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                    }`}>
                      {block.direction}
                    </span>
                    <span className="font-bold text-white">{block.symbol}</span>
                    <span className="text-zinc-600">@ ${block.entryPrice.toFixed(block.symbol.includes("JPY") || block.symbol.includes("BTC") ? 2 : 4)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-400 font-bold font-mono">STAKE: ${block.stake}</span>
                    <span className="rounded bg-emerald-500/10 px-1.5 py-0.5 font-bold font-mono text-emerald-400 animate-pulse bg-emerald-950/20 text-[10px]">
                      {block.timeLeft}s
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 5. Recent Signals ledger matching target screenshot */}
      <div className="mt-4 border-t border-zinc-900 pt-3 flex-1 overflow-hidden min-h-[140px] flex flex-col">
        <div className="mb-2 flex items-center justify-between">
          <label className="font-mono text-[9px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
            RECENT TRADING INSIGHT HISTORY
          </label>
          <span className="font-mono text-[9px] text-zinc-600 font-bold uppercase">WIN RATE: ~92%</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-xs">
          {[
            { symbol: "GBP/USD", direction: "CALL", time: "09:35 AM", outcome: "WIN" },
            { symbol: "USD/JPY", direction: "PUT", time: "09:30 AM", outcome: "WIN" },
            { symbol: "AUD/USD", direction: "CALL", time: "09:25 AM", outcome: "WIN" },
          ].map((item, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between rounded bg-zinc-900/30 p-2 font-mono border border-zinc-900 hover:border-zinc-850"
            >
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">{item.symbol}</span>
                <span className={`text-[9px] font-bold uppercase ${
                  item.direction === "CALL" ? "text-emerald-400" : "text-red-400"
                }`}>
                  {item.direction === "CALL" ? "▲ CALL" : "▼ PUT"}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-zinc-500 text-[10px]">{item.time}</span>
                <span className="rounded-full bg-emerald-500/10 border border-emerald-500/25 px-2 py-0.5 text-[8.5px] font-bold text-emerald-400">
                  {item.outcome}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
