import React, { useState, useEffect } from "react";
import { TrendingUp, TrendingDown, Users, Flame, Shield, ArrowUpRight, Activity, DollarSign } from "lucide-react";
import { Asset } from "../types";

interface LiveAnalysisPanelProps {
  asset: Asset;
}

interface SimulatedTrade {
  id: string;
  timestamp: string;
  traderId: string;
  direction: "CALL" | "PUT";
  stake: number;
  entryPrice: number;
  platform: string;
}

export default function LiveAnalysisPanel({ asset }: LiveAnalysisPanelProps) {
  // Call Ratio starting at a responsive realistic weight (e.g. 58%)
  const [callRatio, setCallRatio] = useState<number>(58);
  const [liveTrades, setLiveTrades] = useState<SimulatedTrade[]>([]);
  const [orderBookLimit, setOrderBookLimit] = useState<Array<{ price: number; volume: number; type: "BID" | "ASK" }>>([]);

  // Mock initial trade ledger
  useEffect(() => {
    // Generate initial live trades
    const initialTrades: SimulatedTrade[] = [];
    const platforms = ["QUOTEX", "POCKET OPTION", "OLYMP TRADE", "BINOMO"];
    for (let i = 0; i < 6; i++) {
      const isCall = Math.random() > 0.45;
      const rFactor = 1 + (Math.random() - 0.5) * 0.002;
      const traderNum = Math.floor(1000 + Math.random() * 9000);
      const stakeVal = [50, 100, 250, 500, 1000][Math.floor(Math.random() * 5)];
      
      const d = new Date(Date.now() - i * 4500);
      initialTrades.push({
        id: Math.random().toString(),
        timestamp: d.toLocaleTimeString("en-US", { hour12: false }),
        traderId: `Trader #${traderNum}`,
        direction: isCall ? "CALL" : "PUT",
        stake: stakeVal,
        entryPrice: asset.currentPrice * rFactor,
        platform: platforms[Math.floor(Math.random() * platforms.length)],
      });
    }
    setLiveTrades(initialTrades);

    // Initial limit order depth simulation
    rebuildOrderDepth();
  }, [asset.symbol]);

  // Rebuild/Tick order book depth levels
  const rebuildOrderDepth = () => {
    const depth: Array<{ price: number; volume: number; type: "BID" | "ASK" }> = [];
    const dpMultiplier = asset.symbol.includes("JPY") || asset.symbol.includes("BTC") ? 2 : 4;
    const tickShift = asset.symbol.includes("JPY") ? 0.01 : asset.symbol.includes("BTC") ? 2.5 : 0.0001;

    // 5 Ask levels above current price
    for (let i = 5; i >= 1; i--) {
      depth.push({
        price: asset.currentPrice + (i * tickShift),
        volume: parseFloat((Math.random() * 8.5 + 0.1).toFixed(2)),
        type: "ASK",
      });
    }
    // 5 Bid levels below current price
    for (let i = 1; i <= 5; i++) {
      depth.push({
        price: asset.currentPrice - (i * tickShift),
        volume: parseFloat((Math.random() * 8.5 + 0.1).toFixed(2)),
        type: "BID",
      });
    }
    setOrderBookLimit(depth);
  };

  // Live simulation tick interval
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Slightly fluctuate Call/Put pressure gauge
      setCallRatio((prev) => {
        const drift = (Math.random() - 0.5) * 6;
        const next = Math.max(25, Math.min(85, prev + drift));
        return parseFloat(next.toFixed(1));
      });

      // 2. Insert new global simulated contract order
      const platforms = ["QUOTEX", "POCKET OPTION", "OLYMP TRADE", "BINOMO"];
      const isCall = Math.random() < (callRatio / 100);
      const traderNum = Math.floor(1000 + Math.random() * 9000);
      const stakeVal = [50, 100, 200, 500, 1000, 1500][Math.floor(Math.random() * 6)];
      const entryPriceOffset = 1 + (Math.random() - 0.5) * 0.0004;

      const newTrade: SimulatedTrade = {
        id: Math.random().toString(),
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
        traderId: `Trader #${traderNum}`,
        direction: isCall ? "CALL" : "PUT",
        stake: stakeVal,
        entryPrice: asset.currentPrice * entryPriceOffset,
        platform: platforms[Math.floor(Math.random() * platforms.length)],
      };

      setLiveTrades((prev) => [newTrade, ...prev.slice(0, 7)]);
      rebuildOrderDepth();
    }, 2200);

    return () => clearInterval(interval);
  }, [callRatio, asset.currentPrice]);

  const putRatio = parseFloat((100 - callRatio).toFixed(1));

  // Determine current consensus label
  const getConsensus = () => {
    if (callRatio >= 70) return { label: "STRONG BUY PRESSURE", color: "text-emerald-400 border-emerald-500/25 bg-emerald-950/10" };
    if (callRatio >= 55) return { label: "MODERATE BULLISH BIAS", color: "text-emerald-400/80 border-emerald-500/15 bg-emerald-950/5" };
    if (callRatio <= 30) return { label: "STRONG SELL PRESSURE", color: "text-red-400 border-red-500/25 bg-red-950/10" };
    if (callRatio <= 45) return { label: "MODERATE BEARISH BIAS", color: "text-red-400/80 border-red-500/15 bg-red-950/5" };
    return { label: "BALANCED SQUEEZE ZONE", color: "text-zinc-400 border-zinc-800 bg-zinc-900/10" };
  };

  const consensus = getConsensus();

  return (
    <div className="flex h-full flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl select-none font-mono">
      
      {/* Panel Title & Active Instrument Tag */}
      <div className="mb-4 flex items-center justify-between border-b border-zinc-900 pb-3">
        <div className="flex items-center gap-1.5">
          <Activity className="h-4.5 w-4.5 text-emerald-400 animate-pulse" />
          <h3 className="font-display text-sm font-bold text-white tracking-widest uppercase">
            CALL / PUT LIVE ANALYSIS
          </h3>
        </div>
        <span className="rounded bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[9px] font-bold text-emerald-400">
          {asset.symbol} LIVE FEED
        </span>
      </div>

      {/* 1. Interactive Dual Liquid Progress Gauge */}
      <div className="mb-4 rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] uppercase font-bold text-zinc-400 flex items-center gap-1">
            <Users className="h-3 w-3 text-emerald-400" /> ACTIVE POSITIONS FLOW
          </span>
          <span className={`rounded-full px-2 py-0.5 text-[8.5px] font-bold border transition-colors ${consensus.color}`}>
            {consensus.label}
          </span>
        </div>

        {/* Dynamic Percentage text numbers */}
        <div className="flex items-baseline justify-between mb-1">
          <div className="flex flex-col">
            <span className="text-2xl font-black text-emerald-400 leading-none">{callRatio}%</span>
            <span className="text-[8px] font-bold text-zinc-500 uppercase mt-1">CALL (BUYERS)</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-2xl font-black text-red-400 leading-none">{putRatio}%</span>
            <span className="text-[8px] font-bold text-zinc-500 uppercase mt-1">PUT (SELLERS)</span>
          </div>
        </div>

        {/* Sliders visual container bar */}
        <div className="relative h-3 w-full rounded-full bg-zinc-900 overflow-hidden flex">
          <div 
            className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-700 ease-out shadow-[0_0_10px_rgba(16,185,129,0.2)]"
            style={{ width: `${callRatio}%` }}
          />
          <div 
            className="h-full bg-gradient-to-r from-red-400 to-red-600 transition-all duration-700 ease-out flex-1"
          />
          {/* Central divider line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-[1.5px] bg-zinc-950 z-10" />
        </div>

        <div className="mt-2.5 grid grid-cols-3 gap-2.5 text-[8.5px] text-zinc-400 uppercase font-bold text-center">
          <div className="p-1 rounded bg-zinc-950/50 border border-zinc-900 leading-tight">
            <span className="block text-zinc-500 text-[7px]">BUYING FORCE</span>
            <span className="text-emerald-400">{callRatio >= 60 ? "ACCUMULATION" : "ABSORPTION"}</span>
          </div>
          <div className="p-1 rounded bg-zinc-950/50 border border-zinc-900 leading-tight">
            <span className="block text-zinc-500 text-[7px]">LIQUIDITY STRIKE</span>
            <span className="text-white">CONGESTED</span>
          </div>
          <div className="p-1 rounded bg-zinc-950/50 border border-zinc-900 leading-tight">
            <span className="block text-zinc-500 text-[7px]">SELLING FORCE</span>
            <span className="text-red-400">{putRatio >= 60 ? "AGGRESSIVE" : "RETRACING"}</span>
          </div>
        </div>
      </div>

      {/* Grid: 2. Interactive Order Depth (L2 Left) & Multi Indicator Checklist (Right) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mb-4">
        
        {/* Order Book / Level 2 order depth simulator */}
        <div className="rounded-xl border border-zinc-900 bg-zinc-900/10 p-3 flex flex-col justify-between">
          <div>
            <h4 className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">
              MINI DEPTH OF MARKET (DOM)
            </h4>
            <div className="space-y-1 text-[9px] tracking-tight">
              {orderBookLimit.map((item, idx) => {
                const decimalPoints = asset.symbol.includes("JPY") || asset.symbol.includes("BTC") ? 2 : 4;
                return (
                  <div key={idx} className="flex items-center justify-between font-mono">
                    <span className={item.type === "ASK" ? "text-red-400" : "text-emerald-400"}>
                      {item.price.toFixed(decimalPoints)}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-zinc-500 text-[8px]">{item.volume} Lot</span>
                      <div className="w-12 bg-zinc-900/60 h-1.5 rounded-sm overflow-hidden relative">
                        <div 
                          className={`h-full ${item.type === "ASK" ? "bg-red-500/30" : "bg-emerald-500/30"}`}
                          style={{ width: `${Math.min(100, item.volume * 10)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Technical standards consensus markers */}
        <div className="rounded-xl border border-zinc-900 bg-zinc-900/10 p-3 flex flex-col justify-between">
          <div>
            <h4 className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">
              OSCILLATOR BIAS CHECKLIST
            </h4>
            
            <div className="space-y-2 text-[10px]">
              <div className="flex justify-between items-center border-b border-zinc-900 pb-1">
                <span className="text-zinc-400 text-[9px]">RSI (14) REBOUND</span>
                <span className={`font-bold px-1 rounded text-[9px] ${callRatio > 55 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                  {callRatio > 55 ? "▲ CALL (BUY)" : "▼ PUT (SELL)"}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-zinc-900 pb-1">
                <span className="text-zinc-400 text-[9px]">MACD WAVE DIVERSE</span>
                <span className={`font-bold px-1 rounded text-[9px] ${callRatio > 48 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                  {callRatio > 48 ? "▲ CALL (BUY)" : "▼ PUT (SELL)"}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-zinc-900 pb-1">
                <span className="text-zinc-400 text-[9px]">BOLLINGER BAND TOUCH</span>
                <span className={`font-bold px-1 rounded text-[9px] ${callRatio < 40 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                  {callRatio < 40 ? "▲ CALL (SQUEEZE)" : "▼ PUT (REBOUND)"}
                </span>
              </div>
              <div className="flex justify-between items-center pb-0.5">
                <span className="text-zinc-400 text-[9px]">STOCH PRESSURE (14)</span>
                <span className={`font-bold px-1 rounded text-[9px] ${callRatio > 62 ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                  {callRatio > 62 ? "▲ CALL (UP)" : "▼ PUT (DOWN)"}
                </span>
              </div>
            </div>
          </div>
          <div className="border-t border-zinc-950 mt-1 pt-1.5 flex items-center gap-1 text-[8px] text-zinc-500 uppercase leading-normal">
            <Shield className="h-3 w-3 text-emerald-400 shrink-0" />
            <span>Aggregate backtest consensus updates instantly.</span>
          </div>
        </div>

      </div>

      {/* 3. Global Terminals Real-Time Trade Stream Feed */}
      <div className="border-t border-zinc-900 pt-3 flex-1 flex flex-col overflow-hidden min-h-[160px]">
        <div className="mb-2 flex items-center justify-between">
          <label className="font-mono text-[9px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            GLOBAL USER ORDERS FEED (LIVE TERMINALS)
          </label>
          <span className="font-mono text-[9px] text-zinc-600 font-bold uppercase">SPEED: ULTRA HIGH</span>
        </div>

        {/* Live transaction loop block */}
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-[10.5px]">
          {liveTrades.map((t) => (
            <div
              key={t.id}
              className="flex items-center justify-between rounded bg-zinc-900/35 px-2.5 py-1.5 border border-zinc-900 hover:border-zinc-800 transition-colors"
            >
              <div className="flex items-center gap-2">
                <span className={`rounded-sm px-1.5 py-0.5 text-[8.5px] font-bold ${
                  t.direction === "CALL" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                }`}>
                  {t.direction === "CALL" ? "▲ CALL" : "▼ PUT"}
                </span>
                <span className="text-zinc-300 font-bold truncate max-w-[85px]">{t.traderId}</span>
                <span className="text-zinc-600">@</span>
                <span className="text-zinc-400 font-medium font-mono text-[9.5px]">
                  {t.entryPrice.toFixed(asset.symbol.includes("JPY") || asset.symbol.includes("BTC") ? 2 : 4)}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="text-zinc-400 font-bold font-mono">${t.stake}</span>
                <span className="text-zinc-600 text-[8px] font-medium tracking-tight uppercase px-1 rounded bg-zinc-950 shadow-sm">
                  {t.platform}
                </span>
                <span className="text-zinc-500 text-[8.5px]">{t.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
