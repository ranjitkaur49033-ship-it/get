import React, { useState, useRef, useEffect } from "react";
import { AreaChart, Eye, Settings2, BarChart3, TrendingUp, Sparkles, Orbit } from "lucide-react";
import { Candlestick } from "../types";

interface InteractiveChartProps {
  symbol: string;
  history: Candlestick[];
  currentPrice: number;
}

export default function InteractiveChart({
  symbol,
  history,
  currentPrice,
}: InteractiveChartProps) {
  const [showVolume, setShowVolume] = useState(true);
  const [showSMA, setShowSMA] = useState(true);
  const [showEMA, setShowEMA] = useState(true);
  const [showBands, setShowBands] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  
  // Ref for tracking chart dimensions and positioning tooltips
  const svgRef = useRef<SVGSVGElement>(null);
  const [mouseCoords, setMouseCoords] = useState<{ x: number; y: number } | null>(null);

  const priceDecimal = symbol.includes("JPY") || symbol.includes("BTC") ? 2 : 4;

  // Technical Calculations
  // Simple Moving Average
  const getSMA = (index: number, period = 10): number | null => {
    if (index < period - 1) return null;
    let sum = 0;
    for (let i = 0; i < period; i++) {
      sum += history[index - i].close;
    }
    return sum / period;
  };

  // Exponential Moving Average
  const getEMA = (index: number, period = 20): number | null => {
    if (index === 0) return history[0].close;
    if (index < period - 1) return null;
    const k = 2 / (period + 1);
    let ema = history[0].close;
    for (let i = 1; i <= index; i++) {
      ema = history[i].close * k + ema * (1 - k);
    }
    return ema;
  };

  // Bollinger Bands (Standard Deviation calculation)
  const getBollingerBands = (index: number, period = 20, multiplier = 2) => {
    const sma = getSMA(index, period);
    if (!sma) return null;
    
    // Variance
    let sqDiffSum = 0;
    for (let i = 0; i < period; i++) {
      const diff = history[index - i].close - sma;
      sqDiffSum += diff * diff;
    }
    const stdDev = Math.sqrt(sqDiffSum / period);
    
    return {
      upper: sma + stdDev * multiplier,
      lower: sma - stdDev * multiplier,
      middle: sma,
    };
  };

  // SVG Coordinates calculations
  const width = 800;
  const height = 360;
  const paddingX = 70;
  const paddingY = 40;

  const chartWidth = width - paddingX * 2;
  const chartHeight = height - paddingY * 2;

  // Max and Min values for calculations
  const prices = history.map((candle) => [candle.high, candle.low]).flat();
  let minPrice = Math.min(...prices);
  let maxPrice = Math.max(...prices);

  // Pad price scales slightly to avoid brushing edges
  const priceRange = maxPrice - minPrice;
  minPrice -= priceRange * 0.08;
  maxPrice += priceRange * 0.08;

  const finalRange = maxPrice - minPrice || 1;

  // Max volume for scaling
  const maxVolume = Math.max(...history.map((h) => h.volume)) || 1;

  const getX = (index: number) => {
    return paddingX + (index / (history.length - 1)) * chartWidth;
  };

  const getY = (price: number) => {
    return paddingY + chartHeight - ((price - minPrice) / finalRange) * chartHeight;
  };

  const getVolumeHeight = (volume: number) => {
    const maxVolHeight = 60; // volume bar takes bottom section
    return (volume / maxVolume) * maxVolHeight;
  };

  // Generate paths for indicator overlays
  let smaPath = "";
  let emaPath = "";
  let bBandUpperPath = "";
  let bBandLowerPath = "";
  let bBandAreaPoints = "";

  history.forEach((_, idx) => {
    const x = getX(idx);
    
    if (showSMA) {
      const sma = getSMA(idx, 10);
      if (sma) smaPath += `${smaPath === "" ? "M" : "L"} ${x} ${getY(sma)}`;
    }
    
    if (showEMA) {
      const ema = getEMA(idx, 20);
      if (ema) emaPath += `${emaPath === "" ? "M" : "L"} ${x} ${getY(ema)}`;
    }

    if (showBands) {
      const babs = getBollingerBands(idx, 20);
      if (babs) {
        const yUpper = getY(babs.upper);
        const yLower = getY(babs.lower);
        bBandUpperPath += `${bBandUpperPath === "" ? "M" : "L"} ${x} ${yUpper}`;
        bBandLowerPath += `${bBandLowerPath === "" ? "M" : "L"} ${x} ${yLower}`;
      }
    }
  });

  // Calculate grid horizontal scales
  const gridLinesCount = 5;
  const gridLines = Array.from({ length: gridLinesCount }).map((_, i) => {
    const val = minPrice + (i / (gridLinesCount - 1)) * (maxPrice - minPrice);
    return {
      price: val,
      y: getY(val),
    };
  });

  // Mouse Interactivity handlers
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMouseCoords({ x, y });

    // Calculate closed index
    const chartRelativeX = x - paddingX * (rect.width / width);
    const scaledChartWidth = chartWidth * (rect.width / width);
    const ratio = chartRelativeX / scaledChartWidth;
    let idx = Math.round(ratio * (history.length - 1));
    idx = Math.max(0, Math.min(history.length - 1, idx));
    setHoveredIndex(idx);
  };

  const handleMouseLeave = () => {
    setHoveredIndex(null);
    setMouseCoords(null);
  };

  // Quick stats computed for card panels
  const activeCandle = hoveredIndex !== null ? history[hoveredIndex] : history[history.length - 1];
  const isGain = activeCandle ? activeCandle.close >= activeCandle.open : true;

  // Active candlestick metrics
  const activeSMA = hoveredIndex !== null ? getSMA(hoveredIndex, 10) : getSMA(history.length - 1, 10);
  const activeEMA = hoveredIndex !== null ? getEMA(hoveredIndex, 20) : getEMA(history.length - 1, 20);

  return (
    <div className="flex flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl h-full">
      {/* Header controls and overlay settings */}
      <div className="mb-4 flex flex-col justify-between gap-3 border-b border-zinc-900 pb-3 sm:flex-row sm:items-center">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-display text-base font-bold text-white tracking-widest uppercase">
              {symbol} REAL-TIME INDEX TRACKER
            </h3>
            <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <span className="font-mono text-[10px] text-zinc-500 uppercase">
            60-SEC interval candles / updated via order flow
          </span>
        </div>

        {/* Dynamic Toolbar config toggles */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowSMA(!showSMA)}
            className={`flex items-center gap-1 rounded px-2.5 py-1 font-mono text-[10px] font-bold tracking-wide uppercase transition-all border ${
              showSMA
                ? "border-amber-500/30 bg-amber-500/10 text-amber-400"
                : "border-zinc-800 bg-zinc-900/30 text-zinc-500 hover:text-zinc-300"
            }`}
          >
            SMA (10)
          </button>
          <button
            onClick={() => setShowEMA(!showEMA)}
            className={`flex items-center gap-1 rounded px-2.5 py-1 font-mono text-[10px] font-bold tracking-wide uppercase transition-all border ${
              showEMA
                ? "border-teal-500/30 bg-teal-500/10 text-teal-300"
                : "border-zinc-800 bg-zinc-900/30 text-zinc-500 hover:text-zinc-300"
            }`}
          >
            EMA (20)
          </button>
          <button
            onClick={() => setShowBands(!showBands)}
            className={`flex items-center gap-1 rounded px-2.5 py-1 font-mono text-[10px] font-bold tracking-wide uppercase transition-all border ${
              showBands
                ? "border-purple-500/30 bg-purple-500/10 text-purple-400"
                : "border-zinc-800 bg-zinc-900/30 text-zinc-500 hover:text-zinc-300"
            }`}
          >
            BANDS
          </button>
          <button
            onClick={() => setShowVolume(!showVolume)}
            className={`flex items-center gap-1.5 rounded px-2.5 py-1 font-mono text-[10px] font-bold tracking-wide uppercase transition-all border ${
              showVolume
                ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-400"
                : "border-zinc-800 bg-zinc-900/30 text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <BarChart3 className="h-3 w-3" />
            VOLUME
          </button>
        </div>
      </div>

      {/* Main HUD overlay for active coordinates */}
      <div className="mb-4 grid grid-cols-2 gap-3 rounded-xl border border-zinc-900 bg-zinc-900/15 p-3 sm:grid-cols-5 md:grid-cols-6">
        <div className="flex flex-col">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">OPEN</span>
          <span className="font-mono text-xs font-bold text-zinc-300">
            {activeCandle ? activeCandle.open.toFixed(priceDecimal) : "..."}
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">HIGH</span>
          <span className="font-mono text-xs font-bold text-emerald-400">
            {activeCandle ? activeCandle.high.toFixed(priceDecimal) : "..."}
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">LOW</span>
          <span className="font-mono text-xs font-bold text-red-400">
            {activeCandle ? activeCandle.low.toFixed(priceDecimal) : "..."}
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">CLOSE</span>
          <span className={`font-mono text-xs font-bold ${isGain ? "text-emerald-400" : "text-red-400"}`}>
            {activeCandle ? activeCandle.close.toFixed(priceDecimal) : "..."}
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">VOLUME</span>
          <span className="font-mono text-xs font-bold text-zinc-400">
            {activeCandle ? activeCandle.volume.toLocaleString() : "..."}
          </span>
        </div>
        <div className="hidden flex-col md:flex">
          <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest">TIME INT</span>
          <span className="font-mono text-xs text-zinc-400">
            {activeCandle ? activeCandle.time : "..."}
          </span>
        </div>
      </div>

      {/* Candlestick Stage Container */}
      <div className="relative flex-1 rounded-xl border border-zinc-900/50 bg-zinc-950/70 p-2 overflow-hidden shadow-inner">
        {/* Real-time Indicator Line Indicator flag */}
        <div className="absolute right-4 top-2 z-10 flex items-center gap-1.5 rounded bg-emerald-500/15 border border-emerald-500/25 px-2 py-0.5">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="font-mono text-[10px] font-bold text-emerald-400">
            LIVE: {currentPrice.toFixed(priceDecimal)}
          </span>
        </div>

        {/* SVG Drawing Canvas */}
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          viewBox={`0 0 ${width} ${height}`}
          preserveAspectRatio="xMidYMid meet"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="cursor-crosshair select-none"
        >
          {/* Background Grid Lines */}
          {gridLines.map((line, index) => (
            <g key={index}>
              <line
                x1={paddingX}
                y1={line.y}
                x2={width - paddingX}
                y2={line.y}
                className="stroke-zinc-900/50"
                strokeWidth="0.75"
                strokeDasharray="4 6"
              />
              <text
                x={width - paddingX + 8}
                y={line.y + 4}
                className="fill-zinc-500 font-mono text-[9px] font-medium"
              >
                {line.price.toFixed(priceDecimal)}
              </text>
            </g>
          ))}

          {/* Time axis text values */}
          {history.map((candle, index) => {
            if (index % 12 !== 0 && index !== history.length - 1) return null;
            const x = getX(index);
            return (
              <text
                key={index}
                x={x}
                y={height - paddingY + 22}
                textAnchor="middle"
                className="fill-zinc-600 font-mono text-[9px]"
              >
                {candle.time}
              </text>
            );
          })}

          {/* Bollinger Bands Shaded Area */}
          {showBands && bBandUpperPath && bBandLowerPath && (
            <path
              d={`${bBandUpperPath} L ${getX(history.length - 1)} ${getY(
                getBollingerBands(history.length - 1)?.lower || minPrice
              )} ${bBandLowerPath.replace(/M /g, "L ").split(" L ").reverse().join(" L ")} Z`}
              className="fill-purple-500/5 stroke-none"
            />
          )}

          {/* Bollinger Bands Outline Paths */}
          {showBands && (
            <>
              <path d={bBandUpperPath} fill="none" className="stroke-purple-500/20" strokeWidth="1" strokeDasharray="2 3" />
              <path d={bBandLowerPath} fill="none" className="stroke-purple-500/20" strokeWidth="1" strokeDasharray="2 3" />
            </>
          )}

          {/* Volume bars display at bottom */}
          {showVolume &&
            history.map((candle, index) => {
              const x = getX(index);
              const volHeight = getVolumeHeight(candle.volume);
              const barWidth = Math.max(1.5, chartWidth / history.length * 0.45);
              const volY = height - paddingY - volHeight - 2;
              const isGreen = candle.close >= candle.open;

              return (
                <rect
                  key={index}
                  x={x - barWidth / 2}
                  y={volY}
                  width={barWidth}
                  height={volHeight}
                  className={isGreen ? "fill-emerald-500/10" : "fill-red-500/10"}
                />
              );
            })}

          {/* Technical Moving Average lines */}
          {showSMA && smaPath && (
            <path d={smaPath} fill="none" className="stroke-amber-500/70" strokeWidth="1.25" />
          )}
          {showEMA && emaPath && (
            <path d={emaPath} fill="none" className="stroke-teal-400/70" strokeWidth="1.25" />
          )}

          {/* Candlestick bars: Body and shadow wicks */}
          {history.map((candle, index) => {
            const x = getX(index);
            const openY = getY(candle.open);
            const closeY = getY(candle.close);
            const highY = getY(candle.high);
            const lowY = getY(candle.low);

            const isGreen = candle.close >= candle.open;
            const colorClass = isGreen ? "stroke-emerald-500" : "stroke-red-500";
            const fillClass = isGreen ? "fill-emerald-500/80" : "fill-red-500/80";

            const candleWidth = Math.max(2, chartWidth / history.length * 0.7);

            return (
              <g key={index} className="opacity-90 transition-opacity hover:opacity-100">
                {/* Shadow wick lines */}
                <line x1={x} y1={highY} x2={x} y2={lowY} className={colorClass} strokeWidth="1.25" />
                
                {/* Real-time bar bodies */}
                <rect
                  x={x - candleWidth / 2}
                  y={Math.min(openY, closeY)}
                  width={candleWidth}
                  height={Math.max(1.2, Math.abs(openY - closeY))}
                  className={`${fillClass} ${colorClass}`}
                  strokeWidth="0.75"
                />
              </g>
            );
          })}

          {/* Current horizontal price baseline */}
          <line
            x1={paddingX}
            y1={getY(currentPrice)}
            x2={width - paddingX}
            y2={getY(currentPrice)}
            className="stroke-emerald-500/35"
            strokeWidth="0.8"
            strokeDasharray="2 3"
          />

          {/* Draggable Hover crosshair tracking guides */}
          {hoveredIndex !== null && mouseCoords && (
            <g>
              {/* Vertical alignment line tracking crosshair index */}
              <line
                x1={getX(hoveredIndex)}
                y1={paddingY}
                x2={getX(hoveredIndex)}
                y2={height - paddingY}
                className="stroke-zinc-500/40"
                strokeWidth="0.75"
                strokeDasharray="2 2"
              />
              {/* Horizontal line following direct cursor position */}
              <line
                x1={paddingX}
                y1={mouseCoords.y}
                x2={width - paddingX}
                y2={mouseCoords.y}
                className="stroke-zinc-500/40"
                strokeWidth="0.75"
                strokeDasharray="2 2"
              />
              {/* Tracker glowing ring focus node */}
              <circle
                cx={getX(hoveredIndex)}
                cy={getY(history[hoveredIndex].close)}
                r="4.5"
                className="fill-emerald-500 stroke-zinc-950"
                strokeWidth="1.5"
              />
            </g>
          )}
        </svg>

        {/* Hover Index Tooltip coordinates box */}
        {hoveredIndex !== null && mouseCoords && (
          <div
            className="absolute rounded-lg border border-zinc-800 bg-zinc-950/95 p-2 font-mono text-[10px] text-zinc-300 shadow-2xl pointer-events-none"
            style={{
              left: `${Math.min(80, Math.max(10, (getX(hoveredIndex) / width) * 100 - 10))}%`,
              top: `${Math.min(65, Math.max(15, (mouseCoords.y / height) * 100 - 15))}%`,
            }}
          >
            <div className="font-bold border-b border-zinc-900 pb-1 mb-1 flex justify-between gap-4 text-white">
              <span>INT PRICE</span>
              <span className={history[hoveredIndex].close >= history[hoveredIndex].open ? "text-emerald-400" : "text-red-400"}>
                {history[hoveredIndex].close.toFixed(priceDecimal)}
              </span>
            </div>
            <div className="space-y-0.5 text-zinc-400">
              <div className="flex justify-between gap-3">
                <span>CHANGE:</span>
                <span className={history[hoveredIndex].close >= history[hoveredIndex].open ? "text-emerald-400" : "text-red-400"}>
                  {(history[hoveredIndex].close - history[hoveredIndex].open).toFixed(priceDecimal)}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span>VOL:</span>
                <span>{history[hoveredIndex].volume}</span>
              </div>
              <div className="flex justify-between gap-3 font-semibold text-zinc-500">
                <span>TIME:</span>
                <span>{history[hoveredIndex].time}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Indicators panel footer display */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-zinc-900/15 p-2 px-3 text-[10px] font-mono text-zinc-500">
        <div className="flex flex-wrap gap-x-4 gap-y-1">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded bg-amber-500/70"></span>
            <span>SMA 10: <span className="text-zinc-300 font-bold">{activeSMA ? activeSMA.toFixed(priceDecimal) : "N/A"}</span></span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded bg-teal-400/70"></span>
            <span>EMA 20: <span className="text-zinc-300 font-bold">{activeEMA ? activeEMA.toFixed(priceDecimal) : "N/A"}</span></span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-wider text-emerald-400">
          <Settings2 className="h-3 w-3" />
          <span>AUTOSCALE RESOLUTION SECURED</span>
        </div>
      </div>
    </div>
  );
}
