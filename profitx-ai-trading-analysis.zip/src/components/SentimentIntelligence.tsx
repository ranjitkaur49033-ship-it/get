import { useState, useEffect } from "react";
import { Sparkles, RefreshCw, Terminal, TrendingUp, DollarSign, Award, Compass, Layers } from "lucide-react";
import { SentimentData } from "../types";

interface SentimentIntelligenceProps {
  symbol: string;
  sentiment: SentimentData | null;
  onRefreshSentiment: () => Promise<void>;
  isLoading: boolean;
}

export default function SentimentIntelligence({
  symbol,
  sentiment,
  onRefreshSentiment,
  isLoading,
}: SentimentIntelligenceProps) {
  // Compute dial percentage color for the sentiment score (-1.0 to +1.0 converted to 0% to 100%)
  const getScorePercentage = (score: number) => {
    return ((score + 1) / 2) * 100;
  };

  const getSentimentColor = (sentimentText: string) => {
    const text = sentimentText.toLowerCase();
    if (text.includes("strong bullish")) return "text-emerald-400 glow-green-text";
    if (text.includes("bullish")) return "text-emerald-400";
    if (text.includes("strong bearish")) return "text-red-400 glow-red-text";
    if (text.includes("bearish")) return "text-red-400";
    return "text-zinc-400";
  };

  const getImpactColor = (impact: string) => {
    const text = impact.toLowerCase();
    if (text.includes("high positive")) return "bg-emerald-500/10 border-emerald-500/30 text-emerald-400";
    if (text.includes("positive")) return "bg-emerald-500/5 border-emerald-500/15 text-emerald-400";
    if (text.includes("high negative")) return "bg-red-500/10 border-red-500/30 text-red-400";
    if (text.includes("negative")) return "bg-red-500/5 border-red-500/15 text-red-500";
    return "bg-zinc-900/45 border-zinc-800 text-zinc-400";
  };

  return (
    <div className="flex flex-col border border-zinc-800 bg-zinc-950/40 p-4 backdrop-blur-md rounded-2xl h-full font-mono">
      {/* Header controls */}
      <div className="mb-4 flex items-center justify-between border-b border-zinc-900 pb-3">
        <div className="flex items-center gap-1.5">
          <Sparkles className="h-4.5 w-4.5 text-emerald-400" />
          <h3 className="font-display text-sm font-bold text-white tracking-widest uppercase">
            SENTIMENT INTELLIGENCE
          </h3>
        </div>

        {/* Refresh tool */}
        <button
          onClick={onRefreshSentiment}
          disabled={isLoading}
          className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-all ${
            isLoading
              ? "border-zinc-800 bg-zinc-900/30 text-zinc-600"
              : "border-zinc-800 bg-zinc-900/40 text-zinc-400 hover:border-emerald-500 hover:text-emerald-400"
          }`}
          title="Analyze and generate sentiment report"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-1 flex-col items-center justify-center py-20">
          <div className="relative flex h-16 w-16 items-center justify-center rounded-full border border-dashed border-emerald-500 bg-zinc-950/60 mb-4 animate-spin [animation-duration:8s]">
            <Terminal className="h-5 w-5 text-emerald-400 [animation-direction:reverse] animate-spin [animation-duration:3s]" />
          </div>
          <span className="font-display text-xs font-bold text-emerald-400 uppercase tracking-widest animate-pulse">
            INTERACTING WITH MODEL...
          </span>
          <span className="mt-1 text-[9px] text-zinc-500 text-center uppercase max-w-[200px]">
            Parsing global news catalysts and oscillators
          </span>
        </div>
      ) : sentiment ? (
        <div className="flex-1 flex flex-col gap-4">
          
          {/* Sentiment Dial Gauge meter */}
          <div className="rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5">
            <div className="flex justify-between items-center mb-1 text-[10px] font-bold text-zinc-500 uppercase">
              <span>SENTIMENT RATING</span>
              <span>SCORE INDEX ({sentiment.score.toFixed(2)})</span>
            </div>

            <div className="flex items-baseline gap-2 mb-2">
              <span className={`font-display text-lg font-black tracking-wider uppercase ${getSentimentColor(sentiment.sentiment)}`}>
                {sentiment.sentiment}
              </span>
            </div>

            {/* Slider rating lines */}
            <div className="relative mt-2 h-2.5 w-full rounded-full bg-zinc-900 overflow-hidden">
              <div 
                className="absolute inset-y-0 left-0 bg-gradient-to-r from-red-500 via-zinc-600 to-emerald-500 transition-all rounded-full"
                style={{ width: `${getScorePercentage(sentiment.score)}%` }}
              />
              {/* Dial pinpoint notch cursor */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white border border-zinc-950"
                style={{ left: `${getScorePercentage(sentiment.score)}%`, transform: "translateX(-50%)" }}
              />
            </div>
            
            <div className="flex justify-between text-[8px] text-zinc-600 font-bold mt-1 uppercase">
              <span>BEARISH (-1)</span>
              <span>NEUTRAL (0)</span>
              <span>BULLISH (+1)</span>
            </div>
          </div>

          {/* Quant Recommendation Block Card */}
          <div className={`rounded-xl border p-3.5 ${
            sentiment.tradingRecommendation.action === "BUY"
              ? "border-emerald-500/20 bg-emerald-950/10 text-emerald-100"
              : sentiment.tradingRecommendation.action === "SELL"
              ? "border-red-500/20 bg-red-950/10 text-red-100"
              : "border-zinc-850 bg-zinc-950 text-zinc-300"
          }`}>
            <h4 className="mb-2 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
              ALGORITHMIC REC: <span className={`font-bold uppercase ${
                sentiment.tradingRecommendation.action === "BUY" ? "text-emerald-400" : sentiment.tradingRecommendation.action === "SELL" ? "text-red-400" : "text-zinc-400"
              }`}>{sentiment.tradingRecommendation.action}</span>
            </h4>

            {/* Price Targets grids */}
            <div className="grid grid-cols-2 gap-3 mt-2 text-[10px]">
              <div className="flex flex-col rounded bg-zinc-950/60 p-2 border border-zinc-900">
                <span className="text-zinc-500 leading-none mb-1 text-[8px] uppercase font-bold">ENTRY ORDER</span>
                <span className="font-mono text-xs font-bold text-white tracking-tight">
                  {sentiment.tradingRecommendation.entry}
                </span>
              </div>
              <div className="flex flex-col rounded bg-zinc-950/60 p-2 border border-zinc-900">
                <span className="text-zinc-500 leading-none mb-1 text-[8px] uppercase font-bold">CONTRACT EXPIRY</span>
                <span className="font-mono text-xs font-bold text-zinc-300">
                  {sentiment.tradingRecommendation.duration}
                </span>
              </div>
              <div className="flex flex-col rounded bg-zinc-950/60 p-2 border border-zinc-900">
                <span className="text-zinc-500 leading-none mb-1 text-[8px] uppercase font-bold">TAKE PROFIT (TP)</span>
                <span className="font-mono text-xs font-bold text-emerald-400 tracking-tight">
                  {sentiment.tradingRecommendation.takeProfit}
                </span>
              </div>
              <div className="flex flex-col rounded bg-zinc-950/60 p-2 border border-zinc-900">
                <span className="text-zinc-500 leading-none mb-1 text-[8px] uppercase font-bold">STOP LOSS (SL)</span>
                <span className="font-mono text-xs font-bold text-red-400 tracking-tight">
                  {sentiment.tradingRecommendation.stopLoss}
                </span>
              </div>
            </div>
          </div>

          {/* AI generated Summary markdown explanation */}
          <div className="rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5 leading-relaxed text-[11.5px] text-zinc-400 select-text">
            <h4 className="mb-2 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
              INTELLIGENCE SUMMARY
            </h4>
            <div className="space-y-1.5 opacity-90 max-h-40 overflow-y-auto pr-1">
              <p className="whitespace-pre-line">{sentiment.summary.replace(/\*\*/g, '').replace(/\*/g, '')}</p>
            </div>
          </div>

          {/* Oscillators technical details list */}
          <div className="rounded-xl border border-zinc-900 bg-zinc-900/15 p-3.5 text-[10px]">
            <h4 className="mb-2 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
              TECHNICAL METEOR OSCILLATORS
            </h4>
            
            <div className="space-y-1.5">
              <div className="flex justify-between items-center bg-zinc-950/50 p-1.5 rounded">
                <span className="text-zinc-500 uppercase font-medium">STRENGTH INDEX (RSI 14)</span>
                <span className="text-zinc-300 font-bold">{sentiment.technicalIndicators.rsi}</span>
              </div>
              <div className="flex justify-between items-center bg-zinc-950/50 p-1.5 rounded">
                <span className="text-zinc-500 uppercase font-medium">CONVERGENCE (MACD 12/26)</span>
                <span className="text-zinc-300 font-bold">{sentiment.technicalIndicators.macd}</span>
              </div>
              <div className="flex justify-between items-center bg-zinc-950/50 p-1.5 rounded">
                <span className="text-zinc-500 uppercase font-medium">MOVING AVERAGES INTEGRAL</span>
                <span className="text-zinc-300 font-bold max-w-[150px] truncate">{sentiment.technicalIndicators.movingAverages}</span>
              </div>
            </div>
          </div>

          {/* Dynamic News headlines and macros impact */}
          <div className="mt-auto border-t border-zinc-900 pt-3 flex-1 flex flex-col justify-end">
            <h4 className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">
              GLOBAL BREAKING NEWS & CATALYSTS
            </h4>
            
            <div className="space-y-2">
              {sentiment.news.map((item, idx) => (
                <div key={idx} className="rounded border border-zinc-900 bg-zinc-950/50 p-2.5 text-xs">
                  <div className="flex justify-between items-start gap-3 mb-1.5">
                    <span className="font-bold text-zinc-200 line-clamp-2 leading-tight">
                      {item.title}
                    </span>
                    <span className={`shrink-0 rounded px-1.5 py-0.5 text-[8px] font-black uppercase border tracking-widest ${getImpactColor(item.impact)}`}>
                      {item.impact}
                    </span>
                  </div>
                  <div className="flex justify-between text-[9px] text-zinc-600 font-bold uppercase">
                    <span>SOURCE: {item.source}</span>
                    <span>{item.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      ) : (
        <div className="flex flex-1 flex-col items-center justify-center py-12 text-center leading-normal">
          <div className="relative flex h-14 w-14 items-center justify-center rounded-full border border-dashed border-zinc-800 bg-zinc-900/30 text-zinc-500 mb-3">
            <Compass className="h-6 w-6" />
          </div>
          <h4 className="font-display text-sm font-bold text-white uppercase tracking-wider mb-1">
            Generate Insights
          </h4>
          <p className="max-w-xs text-[11px] text-zinc-500">
            Fetch real-time comprehensive sentiment reports on demand. This compiles news flow macro dynamics and technical charts directly using the Gemini AI model.
          </p>
        </div>
      )}
    </div>
  );
}
