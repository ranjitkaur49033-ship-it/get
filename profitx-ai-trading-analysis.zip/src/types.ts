export interface Candlestick {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Asset {
  symbol: string;
  name: string;
  category: "Forex" | "Crypto" | "Commodities" | "Stocks";
  basePrice: number;
  currentPrice: number;
  changePercent: number;
  history: Candlestick[];
  high24h: number;
  low24h: number;
  volume24h: number;
}

export interface AISignal {
  symbol: string;
  direction: "CALL" | "PUT";
  confidence: number;
  strength: "STRONG" | "MEDIUM" | "WEAK";
  expiry: string;
  timestamp: string;
  accuracyRating: string;
  reasons: string[];
}

export interface MarketNews {
  title: string;
  source: string;
  timestamp: string;
  impact: "High Positive" | "Positive" | "Neutral" | "Negative" | "High Negative";
}

export interface SentimentData {
  symbol: string;
  sentiment: "Strong Bullish" | "Bullish" | "Neutral" | "Bearish" | "Strong Bearish";
  score: number;
  summary: string;
  news: MarketNews[];
  technicalIndicators: {
    rsi: string;
    macd: string;
    movingAverages: string;
  };
  tradingRecommendation: {
    action: "BUY" | "SELL" | "HOLD";
    entry: string;
    takeProfit: string;
    stopLoss: string;
    duration: string;
  };
}

export interface PriceAlert {
  id: string;
  symbol: string;
  targetPrice: number;
  condition: "ABOVE" | "BELOW";
  triggered: boolean;
  createdAt: string;
}

export interface SystemFeedAlert {
  id: number;
  type: string;
  symbol: string;
  message: string;
  severity: "high" | "medium" | "low";
  time: string;
}
